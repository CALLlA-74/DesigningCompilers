"""s = "fjghjfhfhf ffhfghf hfghjf fghfghg5 456///,\\538824\\3534gd34jg93j53jn345"
sb = bytearray(s, encoding='utf-8')
print(len(s))
print(len(sb))"""

from enum import Enum, unique


@unique
class Types(str, Enum):
    STRING = "string"
    STRING_LITERAL = "string_literal"


import llvmlite.binding as llvm
import llvmlite.ir as llvmir
from ctypes import CFUNCTYPE, c_int32


def init_execution_engine():
    llvm.initialize()
    llvm.initialize_native_target()
    llvm.initialize_native_asmprinter()
    target = llvm.Target.from_default_triple()
    target_machine = target.create_target_machine()

    default_mod = llvm.parse_assembly("")
    return llvm.create_mcjit_compiler(default_mod, target_machine)


def compile_ir(engine, llvm_ir):
    mod = llvm.parse_assembly(str(llvm_ir))
    mod.verify()

    engine.add_module(mod)
    engine.finalize_object()
    engine.run_static_constructors()

    func_ptr = engine.get_function_address("main")
    func = CFUNCTYPE(c_int32)(func_ptr)
    print(func())


def create_global_string(builder: llvmir.IRBuilder, s: str, name: str) -> llvmir.Instruction:
    var_bytes = bytearray(s, encoding="utf-8")
    type_i16_x_len = llvmir.types.ArrayType(llvmir.types.IntType(8), len(var_bytes))
    constant = llvmir.Constant(type_i16_x_len, var_bytes)
    variable = llvmir.GlobalVariable(builder.module, type_i16_x_len, name)
    # variable.linkage = 'private'   # по умолчанию пишем всем private. external будет у interface-полей
    # variable.global_constant = True
    variable.initializer = constant
    variable.align = 1

    zero = llvmir.Constant(llvmir.types.IntType(32), 0)
    variable_pointer = builder.gep(variable, [zero, zero], inbounds=True)
    return variable_pointer


module_ir = llvmir.Module("mod")
builder = llvmir.IRBuilder()

int32 = llvmir.types.IntType(32)
int8p = llvmir.PointerType(llvmir.types.IntType(8))

type_func_scanf = llvmir.types.FunctionType(int32, [int8p], var_arg=True)
type_func_printf = llvmir.types.FunctionType(int32, [int8p], var_arg=True)
type_func_realloc = llvmir.types.FunctionType(int8p, [int8p, int32])
func_scanf = module_ir.declare_intrinsic('scanf', (), type_func_scanf)
func_printf = module_ir.declare_intrinsic('printf', (), type_func_printf)
func_realloc = module_ir.declare_intrinsic('realloc', (), type_func_realloc)

type_func_main = llvmir.types.FunctionType(return_type=int32, args=[])
func_main = llvmir.Function(module_ir, type_func_main, 'main')
zero = llvmir.Constant(int32, 0)
block_main = func_main.append_basic_block('entry')
builder.position_at_end(block_main)

func_ptr_type = llvmir.PointerType(llvmir.FunctionType(int32, [int8p], var_arg=True))
func_ptr = llvmir.GlobalVariable(builder.module, func_ptr_type, name='func_ptr')

"""s = 'asdfsgff'
var_bytes = bytearray(s, encoding='utf-8')
string = llvmir.ArrayType(llvmir.types.IntType(8), 256)    #
var = llvmir.GlobalVariable(builder.module, string, name="b")
#var = builder.alloca(string, name='b')
var.linkage = "private"
var.global_constant = False
#var.initializer = llvmir.Constant(string, var_bytes)
#builder.store(llvmir.Constant(string, var_bytes), var)"""

"""# создаем указатель на динамическую строку
typ = llvmir.PointerType(llvmir.IntType(8))
var = llvmir.GlobalVariable(builder.module, typ, name="var")
var.initializer = llvmir.Constant(typ, None)
var.linkage = "common"
res = builder.call(func_realloc, [builder.load(var), llvmir.Constant(int32, 256)])
builder.store(res, var)

# сохраняем литеральную строку в динамическую
str_val = llvmir.GlobalVariable(builder.module, llvmir.ArrayType(llvmir.IntType(8), 3), name='str_val')
str_val.initializer = llvmir.Constant(llvmir.ArrayType(llvmir.IntType(8), 3), bytearray("abc", "utf-8"))
builder.store(str_val.gep([zero, zero]), var)

# сохраняем другую литеральную строку в динамическую
str_val_2 = llvmir.GlobalVariable(builder.module, llvmir.ArrayType(llvmir.IntType(8), 2), name='str_val_2')
str_val_2.initializer = llvmir.Constant(llvmir.ArrayType(llvmir.IntType(8), 2), bytearray("de", "utf-8"))
builder.store(str_val_2.gep([zero, llvmir.Constant(int32, 1)]), var)"""


"""# создаем дефолтную строку и записываем пустое строковое значение НЕ РАБОТАЕТ
typ_default_str = llvmir.ArrayType(llvmir.IntType(8), 256)
var = llvmir.GlobalVariable(builder.module, typ_default_str, name="var")
#var.initializer = llvmir.Constant(typ_default_str, bytearray("", "utf-8"))
var.linkage = "private"
builder.store(llvmir.Constant(typ_default_str, bytearray("", "utf-8")), ptr=var)"""


builder.call(func_printf, [create_global_string(builder, ' ' * 2700 * 4 + '\n\0', 'a')])
builder.call(func_printf, [create_global_string(builder, 'Русский тестим\n\0', 'p2')])
# builder.call(func_scanf, [create_global_string(builder, '%s\0', 'ddt'), var])       # builder.gep(var, [zero, zero], inbounds=True)
builder.call(func_printf, [create_global_string(builder, '%s\n\0', 'pttrn'),
                           builder.load(var)])  # builder.gep(var, [zero], inbounds=True)
# когда выводим переменную как строку (через %s) то строку (если она НЕ указатель) подаем просто инструкцию-alloca

# при выводе как символ (через %c) символ-строку (если НЕ указатель) подаем через load-инструкцию




# пример описания структуры с полем типа указателя на саму себя
struct2 = module_ir.context.get_identified_type("node")
struct2.set_body(*[llvmir.DoubleType(), llvmir.PointerType(struct2)])


builder.ret(zero)

# print(module_ir)

engine = init_execution_engine()
compile_ir(engine, module_ir)

from typing import Dict
from llvmlite import ir
from llvmlite.ir import Module

from ir_builder.exceptions.CompileException import CompileException
from ir_builder.context import Scopes, TypesEnum, EmbeddedTypesEnum
#import ir_builder.context.Constructs as Constructs
import ir_builder.context.EmbeddedTypes as types
from ir_builder.context.EmbeddedTypes import Constructs
from ir_builder.utils import VarUtils

all_scopes = [Scopes.CONSTS, Scopes.VARS, Scopes.FUNCTIONS, Scopes.LABELS, Scopes.PROCEDURES, Scopes.RECORDS, Scopes.TYPES]


class BaseContext:
    MAX_LEN_STR = 256

    def __init__(self, context_name):
        self.__context_name = context_name
        self.module: Module = ir.Module(context_name)
        self.ir_builder = ir.IRBuilder()
        self.labels = dict()
        self.consts = dict()
        self.vars = dict()

    @staticmethod
    def type():
        return 'context'

    def get_module(self):
        return self.module


class ModuleContext(BaseContext):
    def __init__(self, context_name):
        super().__init__(context_name)
        self.functions = dict()
        self.procedures = dict()
        self.types:Dict[Constructs.Type] = dict()
        self.create_function(return_type=ir.IntType(32), args=[], name='main')
        self.__init_lib()

    @staticmethod
    def type():
        return 'module'

    def get_context_name(self):
        return self.__context_name

    def create_function(self, return_type, args, name:str):
        if not self.is_unique_ident(name):
            raise CompileException("Function name is not unique")
        type_func_main = ir.types.FunctionType(return_type=return_type, args=args)
        func = ir.Function(self.module, type_func_main, name)
        block_main = func.append_basic_block('entry')
        self.ir_builder.position_at_end(block_main)
        self.functions[name] = {"ident": name, "type": type_func_main, "val": func}
        self.__init_types()

    def __init_types(self):
        typ_val = types.TypeIdentifier(typ_ident=TypesEnum.INTEGER)
        self.types[TypesEnum.INTEGER] = Constructs.Type(ident=TypesEnum.INTEGER, typ_val=typ_val, instruct=ir.IntType(64))

        typ_val = types.TypeIdentifier(typ_ident=TypesEnum.REAL)
        self.types[TypesEnum.REAL] = Constructs.Type(ident=TypesEnum.REAL, typ_val=typ_val, instruct=ir.DoubleType())

        typ_val = types.TypeIdentifier(typ_ident=TypesEnum.BOOLEAN)
        self.types[TypesEnum.BOOLEAN] = Constructs.Type(ident=TypesEnum.BOOLEAN, typ_val=typ_val, instruct=ir.IntType(1))

        typ_val = types.TypeIdentifier(typ_ident=TypesEnum.CHAR)
        self.types[TypesEnum.CHAR] = Constructs.Type(ident=TypesEnum.CHAR, typ_val=typ_val, instruct=ir.IntType(8))

        typ_val = types.TypeIdentifier(typ_ident=TypesEnum.STRING)
        self.types[TypesEnum.STRING] = Constructs.Type(ident=TypesEnum.STRING, typ_val=typ_val,
                                                       instruct=ir.PointerType(ir.IntType(8)))       # ir.ArrayType(ir.IntType(8), self.MAX_LEN_STR)

    def __init_lib(self):
        int32 = ir.types.IntType(32)
        int16p = ir.PointerType(ir.types.IntType(8))
        io_func_type = ir.types.FunctionType(int32, [int16p], var_arg=True)

        write_proc = self.module.declare_intrinsic('printf', (), io_func_type)
        read_proc = self.module.declare_intrinsic('scanf', (), io_func_type)

        ident = "write"
        self.procedures[ident] = Constructs.ProcedureOrFunction(ident=ident, arg_list=io_func_type.args,
                                                                func_typ=io_func_type, instruct=write_proc)

        ident = "writeln"
        self.procedures[ident] = Constructs.ProcedureOrFunction(ident=ident, arg_list=io_func_type.args,
                                                                func_typ=io_func_type, instruct=write_proc)

        ident = "read"
        self.procedures[ident] = Constructs.ProcedureOrFunction(ident=ident, arg_list=io_func_type.args,
                                                                func_typ=io_func_type, instruct=read_proc)
        ident = "readln"
        self.procedures[ident] = Constructs.ProcedureOrFunction(ident=ident, arg_list=io_func_type.args,
                                                                func_typ=io_func_type, instruct=read_proc)

    def clear_stdout(self):
        pass    # вызвать writeln с пробелом длины 700*4

    def is_unique_ident(self, ident: str) -> bool:
        return not (ident in list(self.labels.keys()) or ident in list(self.consts.keys()) or
                    ident in list(self.vars.keys()) or ident in list(self.functions.keys()) or
                    ident in list(self.procedures.keys()) or ident in list(self.types.keys()) or
                    ident == self.module.name)

    def get_ir_builder(self) -> ir.IRBuilder:
        return self.ir_builder

    def get_var_by_ident(self, ident: str, search_scopes:list = None):
        ident = ident.lower()
        if search_scopes is None:
            search_scopes = all_scopes

        if Scopes.LABELS in search_scopes:
            res = self.labels.get(ident)
            if res:
                return res
        if Scopes.CONSTS in search_scopes:
            res = self.consts.get(ident)
            if res:
                return res
        if Scopes.VARS in search_scopes:
            res = self.vars.get(ident)
            if res:
                return res
        if Scopes.PROCEDURES in search_scopes:
            res = self.procedures.get(ident)
            if res:
                return res
        if Scopes.FUNCTIONS in search_scopes:
            res = self.functions.get(ident)
            if res:
                return res
        if Scopes.TYPES in search_scopes:
            res = self.types.get(ident)
            if res:
                return res

        return None

    def declare_labels(self, adv_labels: list):
        adv_labels_set = set(adv_labels)
        old_labels_set = set(self.labels.keys())
        if len(adv_labels) != len(adv_labels_set) or old_labels_set.intersection(adv_labels_set):
            raise CompileException(f'Duplicate labels: {self.get_context_name()}')

        for label in adv_labels:
            self.labels[label] = Constructs.Label(label)

    def define_constant(self, const: Constructs.Const):
        is_global = True if self.type() == 'module' else False

        ident = const.ident
        typ = const.typ
        val = const.val
        #ir_builder = self.ir_builder
        if not self.is_unique_ident(ident):
            raise CompileException(f"Const identifier \"{ident}\" must be unique")

        """if typ == TypesEnum.INT_LITERAL:
            const.instruct = VarUtils.create__const_int_var(name=ident, builder=ir_builder, val=val, is_const=True, is_global=is_global)
        elif typ == TypesEnum.REAL_LITERAL:
            const.instruct = VarUtils.create_const_real_var(name=ident, builder=ir_builder, val=val, is_const=True, is_global=is_global)
        elif typ == TypesEnum.STRING_LITERAL:
            const.instruct = VarUtils.create_const_string_var(name=ident, builder=ir_builder, val=val, is_const=True, is_global=is_global)
        elif typ == TypesEnum.CHAR_LITERAL:
            const.instruct = VarUtils.create_const_char_var(name=ident, builder=ir_builder, val=val, is_const=True, is_global=is_global)"""
        if typ == TypesEnum.IDENTIFIER or typ == TypesEnum.SIGNED_IDENTIFIER:
            defined_const:Constructs.Const = self.get_var_by_ident(val, search_scopes=[Scopes.CONSTS])
            if defined_const is None:
                raise CompileException(f"Constant {ident} is not defined")
            val = defined_const.val
            if typ == TypesEnum.SIGNED_IDENTIFIER:
                tmp = defined_const.typ.ident                           # defined_const.typ.typ_val.get_typ()
                if tmp == TypesEnum.INTEGER or tmp == TypesEnum.REAL:
                    v = val.constant
                    val = ir.Constant(typ=defined_const.typ.instruct, constant=v*(-1 if const.sign == '-' else 1))
                else:
                    raise CompileException("String constant must be unsigned")
            const.typ = defined_const.typ
            typ = const.typ
            const.val = val
            const.instruct = VarUtils.create_var_(name=ident, typ=typ, context=self, init_val=val,
                                                  is_const=True, is_global=is_global)
        else:
            const.typ = self.get_var_by_ident(ident=typ.typ_ident, search_scopes=[Scopes.TYPES])
            val = ir.Constant(typ=const.typ.instruct, constant=val)
            const.val = val
            typ = const.typ
            const.instruct = VarUtils.create_var_(name=ident, typ=typ, context=self, init_val=val,
                                                  is_global=is_global, is_const=True)
            #raise CompileException(f"Impossible type of value const: val= {val}; type= {typ}")

        self.consts[ident] = const

    def define_type(self, new_typ: types.CustomType):
        if not self.is_unique_ident(new_typ.ident):
            raise CompileException(f"Identifier of new type \'{new_typ.ident}\' is not unique")
        self.types[new_typ.ident] = self.create_type(new_typ)

    def create_type(self, new_typ: types.CustomType) -> Constructs.Type:
        if new_typ.typ_val.get_type() not in EmbeddedTypesEnum:
            raise CompileException(f"Error in type definition: {new_typ.ident}")
        type_instr = new_typ.typ_val.get_instr(self)
        return Constructs.Type(ident=new_typ.ident, typ_val=new_typ.typ_val, instruct=type_instr)

    def define_variable(self, var: Constructs.Variable):
        if var.typ.get_type() == EmbeddedTypesEnum.IDENTIFIER:
            var.typ = self.get_var_by_ident(ident=var.typ.typ_ident, search_scopes=[Scopes.TYPES])
        else:
            var.typ = self.create_type(new_typ=types.CustomType(ident=None, typ_val=var.typ))

        if var.typ.typ_val.get_type() == EmbeddedTypesEnum.FUNCTION:
            """self.functions[var.ident] = Constructs.ProcedureOrFunction(
                ident=var.ident, func_typ=var.typ.instruct
            )"""
            pass
        elif var.typ.typ_val.get_type() == EmbeddedTypesEnum.PROCEDURE:
            """self.functions[var.ident] = Constructs.ProcedureOrFunction(
                ident=var.ident, func_typ=var.typ.instruct
            )"""
            pass
        else:
            typ = var.typ
            self.vars[var.ident] = VarUtils.create_var_(name=var.ident, typ=typ, context=self, is_global=True)
        # 2) в каждом классе в EmbeddedTypes реализовать функции для записи/получения значения в переменную заданного типа


class ProcedureContext(BaseContext):
    def __init__(self, context_name, module_context: ModuleContext):
        super().__init__(context_name)
        self.module_context: ModuleContext = module_context

    @staticmethod
    def type():
        return 'procedure'

    def get_context_name(self):
        return self.module_context.get_context_name() + '.' + self.__context_name

    def is_unique_ident(self, ident: str) -> bool:
        return not (ident in self.labels or ident in self.consts or ident in self.vars or ident == self.get_context_name())

    def get_ir_builder(self) -> ir.IRBuilder:
        return self.module_context.get_ir_builder()

    def get_var_by_ident(self, ident: str, search_scopes:list = None):
        ident = ident.lower()
        if search_scopes is None:
            search_scopes = all_scopes

        if Scopes.LABELS in search_scopes:
            res = self.labels.get(ident)
            if res:
                return res
        if Scopes.CONSTS in search_scopes:
            res = self.consts.get(ident)
            if res:
                return res
        if Scopes.VARS in search_scopes:
            res = self.vars.get(ident)
            if res:
                return res

        return self.module_context.get_var_by_ident(ident)

    def declare_labels(self, adv_labels: list):
        adv_labels_set = set(adv_labels)
        old_labels_set = set(self.labels.keys())
        if len(adv_labels) != len(adv_labels_set) or old_labels_set.intersection(adv_labels_set):
            raise CompileException(f'Duplicate labels: {self.get_context_name()}')

        for label in adv_labels:
            self.labels[label] = Constructs.Label(label)

    def define_constant(self, const: Constructs.Const):
        is_global = True if self.type() == 'module' else False

        ident = const.ident
        typ = const.typ
        val = const.val
        #ir_builder = self.ir_builder
        if not self.is_unique_ident(ident):
            raise CompileException(f"Const identifier \"{ident}\" must be unique")

        """if typ == TypesEnum.INT_LITERAL:
            const.instruct = VarUtils.create__const_int_var(name=ident, builder=ir_builder, val=val, is_const=True, is_global=is_global)
        elif typ == TypesEnum.REAL_LITERAL:
            const.instruct = VarUtils.create_const_real_var(name=ident, builder=ir_builder, val=val, is_const=True, is_global=is_global)
        elif typ == TypesEnum.STRING_LITERAL:
            const.instruct = VarUtils.create_const_string_var(name=ident, builder=ir_builder, val=val, is_const=True, is_global=is_global)
        elif typ == TypesEnum.CHAR_LITERAL:
            const.instruct = VarUtils.create_const_char_var(name=ident, builder=ir_builder, val=val, is_const=True, is_global=is_global)"""
        if typ == TypesEnum.IDENTIFIER or typ == TypesEnum.SIGNED_IDENTIFIER:
            defined_const:Constructs.Const = self.get_var_by_ident(val, search_scopes=[Scopes.CONSTS])
            if defined_const is None:
                raise CompileException(f"Constant {ident} is not defined")
            val = defined_const.val
            if typ == TypesEnum.SIGNED_IDENTIFIER:
                tmp = defined_const.typ.typ_val.get_typ()
                if tmp == TypesEnum.INTEGER or tmp == TypesEnum.REAL:
                    val *= (-1 if const.sign == '-' else 1)
                else:
                    raise CompileException("String constant must be unsigned")
            const.typ = defined_const.typ
            const.val = val
            typ = const.typ
            const.instruct = VarUtils.create_var_(name=ident, typ=typ, context=self, init_val=val,
                                                  is_const=True, is_global=is_global)
        else:
            const.typ = self.get_var_by_ident(ident=typ.typ_ident, search_scopes=[Scopes.TYPES])
            val = ir.Constant(typ=const.typ.instruct, constant=val)
            typ = const.typ
            const.instruct = VarUtils.create_var_(name=ident, typ=typ, context=self, init_val=val,
                                                  is_global=is_global, is_const=True)
            #raise CompileException(f"Impossible type of value const: val= {val}; type= {typ}")

        self.consts[ident] = const


    """def define_constant(self, const: Constructs.Const):
        is_global = True if self.type() == 'module' else False

        ident = const.ident
        typ = const.typ
        val = const.val
        ir_builder = self.ir_builder
        if not self.is_unique_ident(ident):
            raise CompileException(f"Const identifier \"{ident}\" must be unique")

        if typ == TypesEnum.INT_LITERAL:
            const.instruct = VarUtils.create__const_int_var(name=ident, builder=ir_builder, val=val, is_const=True, is_global=is_global)
        elif typ == TypesEnum.REAL_LITERAL:
            const.instruct = VarUtils.create_const_real_var(name=ident, builder=ir_builder, val=val, is_const=True, is_global=is_global)
        elif typ == TypesEnum.STRING_LITERAL:
            const.instruct = VarUtils.create_const_string_var(name=ident, builder=ir_builder, val=val, is_const=True, is_global=is_global)
        elif typ == TypesEnum.CHAR_LITERAL:
            const.instruct = VarUtils.create_const_char_var(name=ident, builder=ir_builder, val=val, is_const=True, is_global=is_global)
        elif typ == TypesEnum.IDENTIFIER or typ == TypesEnum.SIGNED_IDENTIFIER:
            defined_const = self.get_var_by_ident(val, search_scopes=[Scopes.CONSTS])
            if defined_const is None:
                raise CompileException(f"Constant {ident} is not defined")
            val = defined_const.val
            if typ == TypesEnum.SIGNED_IDENTIFIER:
                val *= (-1 if const.sign == '-' else 1)
            const.instruct = VarUtils.create_const_var_(name=ident, typ=defined_const.typ, builder=ir_builder, val=val, is_const=True, is_global=is_global)
        else:
            raise CompileException(f"Impossible type of value const: val= {val}; type= {typ}")

        self.consts[ident] = const"""

    """def define_type(self, new_typ: types.CustomType):
        self.module_context.define_type(new_typ)"""

    def create_type(self, new_typ: types.CustomType):
        return self.module_context.create_type(new_typ=new_typ)

    def define_variable(self, var: Constructs.Variable):
        if var.typ.get_type() == EmbeddedTypesEnum.IDENTIFIER:
            var.typ = self.get_var_by_ident(ident=var.typ.typ_ident, search_scopes=[Scopes.TYPES])
        else:
            var.typ = self.create_type(new_typ=types.CustomType(ident=None, typ_val=var.typ))

        if var.typ.typ_val.get_type() == EmbeddedTypesEnum.FUNCTION:
            pass
            """self.functions[var.ident] = Constructs.ProcedureOrFunction(
                ident=var.ident, func_typ=var.typ.instruct
            )"""
        elif var.typ.typ_val.get_type() == EmbeddedTypesEnum.PROCEDURE:
            pass
            """self.functions[var.ident] = Constructs.ProcedureOrFunction(
                ident=var.ident, func_typ=var.typ.instruct
            )"""
        else:
            typ = var.typ
            self.vars[var.ident] = VarUtils.create_var_(name=var.ident, typ=typ, context=self, is_global=True)

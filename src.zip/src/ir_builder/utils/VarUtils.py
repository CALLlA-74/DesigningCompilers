import typing

from ir_builder.exceptions.CompileException import CompileException
from llvmlite import ir as llvmir
from ir_builder.context import TypesEnum, EmbeddedTypesEnum, Constructs
#from ir_builder.context.EmbeddedTypes import AbstractType
#from ir_builder.context.Context import ModuleContext, ProcedureContext


def parse_real(number: str) -> float:
    try:
        return float(number)
    except Exception as e:
        raise CompileException(f'{str(e)}')


def parse_int(number: str) -> int:
    try:
        return int(number)
    except Exception as e:
        raise CompileException(f'{str(e)}')


"""def create__const_int_var(name:str, builder:llvmir.IRBuilder, val:int = 0, is_global:bool = False, is_const:bool = False):
    int64 = llvmir.IntType(64)
    if is_global or is_const:
        variable = llvmir.GlobalVariable(builder.module, int64, name=name)
        variable.linkage = "private"
        variable.global_constant = is_const
    else:
        variable = builder.alloca(int64, name=name)

    builder.store(llvmir.Constant(int64, val), variable)
    return variable


def create_const_real_var(name:str, builder:llvmir.IRBuilder, val:float = 0.0, is_global:bool = False, is_const:bool = False):
    float64 = llvmir.DoubleType()
    if is_global or is_const:
        variable = llvmir.GlobalVariable(builder.module, float64, name=name)
        variable.linkage = "private"
        variable.global_constant = is_const
    else:
        variable = builder.alloca(float64, name=name)

    builder.store(llvmir.Constant(float64, val), variable)
    return variable


def create_const_string_var(name:str, builder:llvmir.IRBuilder, val:str = '', is_global:bool = False, is_const:bool = False):
    val_bytes = bytearray(val, encoding="utf-8")
    string = llvmir.ArrayType(llvmir.types.IntType(8), len(val_bytes))
    if is_global or is_const:
        variable = llvmir.GlobalVariable(builder.module, string, name=name)
        variable.linkage = "private"
        variable.global_constant = is_const
    else:
        variable = builder.alloca(string, name=name)

    builder.store(llvmir.Constant(string, val_bytes), variable)
    return variable


def create_const_char_var(name:str, builder:llvmir.IRBuilder, val:str = None, is_global:bool = False, is_const:bool = False):
    if len(val) > 1:
        raise CompileException(f"Got string \'{val}\' but char expected")
    elif len(val) < 1:
        raise CompileException(f"Char variable isn\'t initialized")
    val_bytes = bytearray(val, encoding="utf-8")
    char = llvmir.ArrayType(llvmir.types.IntType(8), len(val_bytes))
    if is_global or is_const:
        variable = llvmir.GlobalVariable(builder.module, char, name=name)
        variable.linkage = "private"
        variable.global_constant = is_const
    else:
        variable = builder.alloca(char, name=name)

    builder.store(llvmir.Constant(char, val_bytes), variable)
    return variable


def create_const_var_(name:str, typ:TypesEnum, builder:llvmir.IRBuilder, val, is_global:bool = False,
                      is_const:bool = False):
    if typ == TypesEnum.INT_LITERAL:
        return create__const_int_var(name=name, builder=builder, val=val, is_global=is_global, is_const=is_const)
    elif typ == TypesEnum.REAL_LITERAL:
        return create_const_real_var(name=name, builder=builder, val=val, is_global=is_global, is_const=is_const)
    elif typ == TypesEnum.STRING_LITERAL:
        return create_const_string_var(name=name, builder=builder, val=val, is_global=is_global, is_const=is_const)
    elif typ == TypesEnum.CHAR_LITERAL:
        return create_const_char_var(name=name, builder=builder, val=val, is_global=is_global, is_const=is_const)"""


def create_var_(name:str, typ: Constructs.Type, context,        # typing.Union[ModuleContext, ProcedureContext]
                init_val=None, is_global:bool = False, is_const:bool = False):
    if init_val is None:
        init_val = get_default_value(typ=typ)
    if is_global or is_const:
        variable = llvmir.GlobalVariable(context.module, typ.instruct, name=name)
        variable.linkage = "private"
        variable.global_constant = is_const
        variable.initializer = init_val
    else:
        variable = context.ir_builder.alloca(typ.instruct, name=name)
        context.ir_builder.store(value=init_val, ptr=variable)
    return variable


def get_default_value(typ: Constructs.Type):
    if typ.get_type() == EmbeddedTypesEnum.IDENTIFIER:
        pass


"""def type_to_llvm_type(var: dict):
    if var["type"] == Types.INT_LITERAL or type == Types.INT:
        return llvmir.IntType(64)
    elif var["type"] == Types.REAL_LITERAL or Types.REAL:
        return llvmir.DoubleType()
    elif var["type"] == Types.STRING or Types.STRING_LITERAL:
        val_bytes = bytearray(var["val"], encoding="utf-8")
        return llvmir.ArrayType(llvmir.types.IntType(8), len(val_bytes))
    elif var["type"] == Types.CHAR_LITERAL or Types.CHAR:
        if len(var["val"]) != 1:
            return None
        val_bytes = bytearray(var["val"], encoding="utf-8")
        return llvmir.ArrayType(llvmir.types.IntType(8), len(val_bytes))
    return None"""

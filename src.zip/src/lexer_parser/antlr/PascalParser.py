# Generated from Pascal.g4 by ANTLR 4.13.1
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,80,800,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,39,
        2,40,7,40,2,41,7,41,2,42,7,42,2,43,7,43,2,44,7,44,2,45,7,45,2,46,
        7,46,2,47,7,47,2,48,7,48,2,49,7,49,2,50,7,50,2,51,7,51,2,52,7,52,
        2,53,7,53,2,54,7,54,2,55,7,55,2,56,7,56,2,57,7,57,2,58,7,58,2,59,
        7,59,2,60,7,60,2,61,7,61,2,62,7,62,2,63,7,63,2,64,7,64,2,65,7,65,
        2,66,7,66,2,67,7,67,2,68,7,68,2,69,7,69,2,70,7,70,2,71,7,71,2,72,
        7,72,2,73,7,73,2,74,7,74,2,75,7,75,2,76,7,76,2,77,7,77,2,78,7,78,
        2,79,7,79,2,80,7,80,2,81,7,81,2,82,7,82,2,83,7,83,2,84,7,84,2,85,
        7,85,2,86,7,86,2,87,7,87,2,88,7,88,2,89,7,89,2,90,7,90,2,91,7,91,
        2,92,7,92,2,93,7,93,2,94,7,94,2,95,7,95,2,96,7,96,1,0,1,0,3,0,197,
        8,0,1,0,1,0,1,0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,3,1,209,8,1,1,1,1,1,
        1,1,1,1,1,1,1,1,3,1,217,8,1,1,2,1,2,1,3,1,3,1,3,1,3,1,3,1,3,1,3,
        5,3,228,8,3,10,3,12,3,231,9,3,1,3,1,3,1,4,1,4,1,4,1,4,1,5,1,5,1,
        5,1,5,5,5,243,8,5,10,5,12,5,246,9,5,1,5,1,5,1,6,1,6,1,7,1,7,1,7,
        1,7,4,7,256,8,7,11,7,12,7,257,1,8,1,8,1,8,1,8,1,9,1,9,1,9,1,9,1,
        9,1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,10,3,10,279,8,10,
        1,11,1,11,3,11,283,8,11,1,12,1,12,1,13,1,13,1,14,1,14,1,15,1,15,
        1,16,1,16,1,17,1,17,1,17,1,17,4,17,299,8,17,11,17,12,17,300,1,18,
        1,18,1,18,1,18,1,18,3,18,308,8,18,1,19,1,19,3,19,312,8,19,1,19,1,
        19,1,19,1,20,1,20,3,20,319,8,20,1,21,1,21,1,21,3,21,324,8,21,1,22,
        1,22,1,22,1,22,3,22,330,8,22,1,23,1,23,1,23,1,23,1,24,1,24,1,24,
        1,24,1,25,1,25,3,25,342,8,25,1,26,1,26,1,26,3,26,347,8,26,1,27,1,
        27,1,27,1,27,3,27,353,8,27,1,28,1,28,1,28,1,28,3,28,359,8,28,1,28,
        1,28,1,29,1,29,1,29,1,29,1,29,1,29,1,29,1,29,1,29,1,29,1,29,1,29,
        1,29,1,29,3,29,377,8,29,1,30,1,30,1,30,5,30,382,8,30,10,30,12,30,
        385,9,30,1,31,1,31,1,32,1,32,1,33,1,33,3,33,393,8,33,1,33,1,33,1,
        34,1,34,1,34,3,34,400,8,34,1,34,3,34,403,8,34,1,35,1,35,1,35,5,35,
        408,8,35,10,35,12,35,411,9,35,1,36,1,36,1,36,1,36,1,37,1,37,1,37,
        1,37,1,37,1,37,5,37,423,8,37,10,37,12,37,426,9,37,1,38,1,38,1,38,
        1,38,1,38,3,38,433,8,38,1,39,1,39,1,39,1,39,1,39,1,39,1,40,1,40,
        1,40,1,40,1,41,1,41,1,42,1,42,1,42,1,42,3,42,451,8,42,1,43,1,43,
        1,43,1,44,1,44,1,44,1,44,5,44,460,8,44,10,44,12,44,463,9,44,1,44,
        1,44,1,45,1,45,1,45,1,45,1,46,1,46,1,46,1,47,1,47,3,47,476,8,47,
        1,48,1,48,1,48,3,48,481,8,48,1,48,1,48,1,48,1,49,1,49,1,49,1,49,
        5,49,490,8,49,10,49,12,49,493,9,49,1,49,1,49,1,50,1,50,1,50,1,50,
        1,50,1,50,1,50,3,50,504,8,50,1,51,1,51,1,51,1,51,1,52,1,52,1,52,
        5,52,513,8,52,10,52,12,52,516,9,52,1,53,1,53,1,53,5,53,521,8,53,
        10,53,12,53,524,9,53,1,54,1,54,1,54,3,54,529,8,54,1,54,1,54,1,54,
        1,54,1,54,1,55,1,55,1,56,1,56,1,56,1,56,1,56,3,56,543,8,56,1,57,
        1,57,3,57,547,8,57,1,58,1,58,1,58,1,58,3,58,553,8,58,1,59,1,59,1,
        59,1,59,1,60,1,60,1,60,3,60,562,8,60,1,60,1,60,1,60,1,60,5,60,568,
        8,60,10,60,12,60,571,9,60,1,60,1,60,1,60,1,60,1,60,1,60,5,60,579,
        8,60,10,60,12,60,582,9,60,1,60,1,60,1,60,1,60,1,60,5,60,589,8,60,
        10,60,12,60,592,9,60,1,61,1,61,1,61,1,61,3,61,598,8,61,1,62,1,62,
        1,63,1,63,1,63,1,63,3,63,606,8,63,1,64,1,64,1,65,1,65,1,65,1,65,
        3,65,614,8,65,1,66,1,66,1,67,3,67,619,8,67,1,67,1,67,1,68,1,68,1,
        68,1,68,1,68,1,68,1,68,1,68,1,68,1,68,1,68,3,68,634,8,68,1,69,1,
        69,1,69,1,69,3,69,640,8,69,1,70,1,70,1,70,1,70,1,70,1,71,1,71,1,
        71,5,71,650,8,71,10,71,12,71,653,9,71,1,72,1,72,1,72,1,72,1,72,1,
        72,1,72,1,72,3,72,663,8,72,1,73,1,73,1,73,5,73,668,8,73,10,73,12,
        73,671,9,73,1,73,3,73,674,8,73,1,74,1,74,1,74,3,74,679,8,74,1,75,
        1,75,1,75,1,75,1,75,3,75,686,8,75,1,76,1,76,5,76,690,8,76,10,76,
        12,76,693,9,76,1,77,1,77,1,77,1,78,1,78,1,78,1,79,1,79,1,80,1,80,
        1,81,1,81,1,81,1,81,3,81,709,8,81,1,82,1,82,1,82,1,82,1,83,1,83,
        1,83,5,83,718,8,83,10,83,12,83,721,9,83,1,84,1,84,3,84,725,8,84,
        1,85,1,85,1,85,1,85,1,85,1,85,3,85,733,8,85,1,86,1,86,1,86,1,86,
        1,86,1,86,5,86,741,8,86,10,86,12,86,744,9,86,1,86,1,86,1,86,3,86,
        749,8,86,1,86,1,86,1,87,1,87,1,87,1,87,1,88,1,88,1,88,3,88,760,8,
        88,1,89,1,89,1,89,1,89,1,89,1,90,1,90,1,90,1,90,1,90,1,91,1,91,1,
        91,1,91,1,91,1,91,1,91,1,92,1,92,1,92,1,92,1,93,1,93,1,94,1,94,1,
        95,1,95,1,95,1,95,1,95,1,96,1,96,1,96,5,96,795,8,96,10,96,12,96,
        798,9,96,1,96,0,0,97,0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,
        32,34,36,38,40,42,44,46,48,50,52,54,56,58,60,62,64,66,68,70,72,74,
        76,78,80,82,84,86,88,90,92,94,96,98,100,102,104,106,108,110,112,
        114,116,118,120,122,124,126,128,130,132,134,136,138,140,142,144,
        146,148,150,152,154,156,158,160,162,164,166,168,170,172,174,176,
        178,180,182,184,186,188,190,192,0,7,1,0,41,42,1,0,72,73,5,0,4,4,
        6,6,20,20,30,30,70,70,2,0,19,19,49,54,2,0,26,26,41,42,4,0,1,1,9,
        9,22,22,43,44,2,0,11,11,35,35,798,0,194,1,0,0,0,2,216,1,0,0,0,4,
        218,1,0,0,0,6,229,1,0,0,0,8,234,1,0,0,0,10,238,1,0,0,0,12,249,1,
        0,0,0,14,251,1,0,0,0,16,259,1,0,0,0,18,263,1,0,0,0,20,278,1,0,0,
        0,22,282,1,0,0,0,24,284,1,0,0,0,26,286,1,0,0,0,28,288,1,0,0,0,30,
        290,1,0,0,0,32,292,1,0,0,0,34,294,1,0,0,0,36,302,1,0,0,0,38,309,
        1,0,0,0,40,316,1,0,0,0,42,323,1,0,0,0,44,329,1,0,0,0,46,331,1,0,
        0,0,48,335,1,0,0,0,50,341,1,0,0,0,52,346,1,0,0,0,54,352,1,0,0,0,
        56,354,1,0,0,0,58,376,1,0,0,0,60,378,1,0,0,0,62,386,1,0,0,0,64,388,
        1,0,0,0,66,390,1,0,0,0,68,402,1,0,0,0,70,404,1,0,0,0,72,412,1,0,
        0,0,74,416,1,0,0,0,76,432,1,0,0,0,78,434,1,0,0,0,80,440,1,0,0,0,
        82,444,1,0,0,0,84,450,1,0,0,0,86,452,1,0,0,0,88,455,1,0,0,0,90,466,
        1,0,0,0,92,470,1,0,0,0,94,475,1,0,0,0,96,477,1,0,0,0,98,485,1,0,
        0,0,100,503,1,0,0,0,102,505,1,0,0,0,104,509,1,0,0,0,106,517,1,0,
        0,0,108,525,1,0,0,0,110,535,1,0,0,0,112,542,1,0,0,0,114,546,1,0,
        0,0,116,552,1,0,0,0,118,554,1,0,0,0,120,561,1,0,0,0,122,593,1,0,
        0,0,124,599,1,0,0,0,126,601,1,0,0,0,128,607,1,0,0,0,130,609,1,0,
        0,0,132,615,1,0,0,0,134,618,1,0,0,0,136,633,1,0,0,0,138,639,1,0,
        0,0,140,641,1,0,0,0,142,646,1,0,0,0,144,662,1,0,0,0,146,673,1,0,
        0,0,148,675,1,0,0,0,150,680,1,0,0,0,152,687,1,0,0,0,154,694,1,0,
        0,0,156,697,1,0,0,0,158,700,1,0,0,0,160,702,1,0,0,0,162,708,1,0,
        0,0,164,710,1,0,0,0,166,714,1,0,0,0,168,724,1,0,0,0,170,726,1,0,
        0,0,172,734,1,0,0,0,174,752,1,0,0,0,176,759,1,0,0,0,178,761,1,0,
        0,0,180,766,1,0,0,0,182,771,1,0,0,0,184,778,1,0,0,0,186,782,1,0,
        0,0,188,784,1,0,0,0,190,786,1,0,0,0,192,791,1,0,0,0,194,196,3,2,
        1,0,195,197,5,68,0,0,196,195,1,0,0,0,196,197,1,0,0,0,197,198,1,0,
        0,0,198,199,3,6,3,0,199,200,5,63,0,0,200,201,5,0,0,1,201,1,1,0,0,
        0,202,203,5,29,0,0,203,208,3,4,2,0,204,205,5,55,0,0,205,206,3,104,
        52,0,206,207,5,56,0,0,207,209,1,0,0,0,208,204,1,0,0,0,208,209,1,
        0,0,0,209,210,1,0,0,0,210,211,5,47,0,0,211,217,1,0,0,0,212,213,5,
        67,0,0,213,214,3,4,2,0,214,215,5,47,0,0,215,217,1,0,0,0,216,202,
        1,0,0,0,216,212,1,0,0,0,217,3,1,0,0,0,218,219,5,77,0,0,219,5,1,0,
        0,0,220,228,3,10,5,0,221,228,3,14,7,0,222,228,3,34,17,0,223,228,
        3,88,44,0,224,228,3,92,46,0,225,228,3,8,4,0,226,228,5,71,0,0,227,
        220,1,0,0,0,227,221,1,0,0,0,227,222,1,0,0,0,227,223,1,0,0,0,227,
        224,1,0,0,0,227,225,1,0,0,0,227,226,1,0,0,0,228,231,1,0,0,0,229,
        227,1,0,0,0,229,230,1,0,0,0,230,232,1,0,0,0,231,229,1,0,0,0,232,
        233,3,164,82,0,233,7,1,0,0,0,234,235,5,69,0,0,235,236,3,104,52,0,
        236,237,5,47,0,0,237,9,1,0,0,0,238,239,5,21,0,0,239,244,3,12,6,0,
        240,241,5,46,0,0,241,243,3,12,6,0,242,240,1,0,0,0,243,246,1,0,0,
        0,244,242,1,0,0,0,244,245,1,0,0,0,245,247,1,0,0,0,246,244,1,0,0,
        0,247,248,5,47,0,0,248,11,1,0,0,0,249,250,3,24,12,0,250,13,1,0,0,
        0,251,255,5,8,0,0,252,253,3,16,8,0,253,254,5,47,0,0,254,256,1,0,
        0,0,255,252,1,0,0,0,256,257,1,0,0,0,257,255,1,0,0,0,257,258,1,0,
        0,0,258,15,1,0,0,0,259,260,3,4,2,0,260,261,5,49,0,0,261,262,3,20,
        10,0,262,17,1,0,0,0,263,264,5,7,0,0,264,265,5,55,0,0,265,266,3,24,
        12,0,266,267,5,56,0,0,267,19,1,0,0,0,268,279,3,22,11,0,269,270,3,
        28,14,0,270,271,3,22,11,0,271,279,1,0,0,0,272,279,3,4,2,0,273,274,
        3,28,14,0,274,275,3,4,2,0,275,279,1,0,0,0,276,279,3,32,16,0,277,
        279,3,18,9,0,278,268,1,0,0,0,278,269,1,0,0,0,278,272,1,0,0,0,278,
        273,1,0,0,0,278,276,1,0,0,0,278,277,1,0,0,0,279,21,1,0,0,0,280,283,
        3,24,12,0,281,283,3,26,13,0,282,280,1,0,0,0,282,281,1,0,0,0,283,
        23,1,0,0,0,284,285,5,79,0,0,285,25,1,0,0,0,286,287,5,80,0,0,287,
        27,1,0,0,0,288,289,7,0,0,0,289,29,1,0,0,0,290,291,7,1,0,0,291,31,
        1,0,0,0,292,293,5,78,0,0,293,33,1,0,0,0,294,298,5,36,0,0,295,296,
        3,36,18,0,296,297,5,47,0,0,297,299,1,0,0,0,298,295,1,0,0,0,299,300,
        1,0,0,0,300,298,1,0,0,0,300,301,1,0,0,0,301,35,1,0,0,0,302,303,3,
        4,2,0,303,307,5,49,0,0,304,308,3,42,21,0,305,308,3,38,19,0,306,308,
        3,40,20,0,307,304,1,0,0,0,307,305,1,0,0,0,307,306,1,0,0,0,308,37,
        1,0,0,0,309,311,5,16,0,0,310,312,3,98,49,0,311,310,1,0,0,0,311,312,
        1,0,0,0,312,313,1,0,0,0,313,314,5,48,0,0,314,315,3,110,55,0,315,
        39,1,0,0,0,316,318,5,28,0,0,317,319,3,98,49,0,318,317,1,0,0,0,318,
        319,1,0,0,0,319,41,1,0,0,0,320,324,3,44,22,0,321,324,3,52,26,0,322,
        324,3,86,43,0,323,320,1,0,0,0,323,321,1,0,0,0,323,322,1,0,0,0,324,
        43,1,0,0,0,325,330,3,46,23,0,326,330,3,48,24,0,327,330,3,50,25,0,
        328,330,3,56,28,0,329,325,1,0,0,0,329,326,1,0,0,0,329,327,1,0,0,
        0,329,328,1,0,0,0,330,45,1,0,0,0,331,332,5,55,0,0,332,333,3,104,
        52,0,333,334,5,56,0,0,334,47,1,0,0,0,335,336,3,20,10,0,336,337,5,
        64,0,0,337,338,3,20,10,0,338,49,1,0,0,0,339,342,3,4,2,0,340,342,
        7,2,0,0,341,339,1,0,0,0,341,340,1,0,0,0,342,51,1,0,0,0,343,344,5,
        27,0,0,344,347,3,54,27,0,345,347,3,54,27,0,346,343,1,0,0,0,346,345,
        1,0,0,0,347,53,1,0,0,0,348,353,3,58,29,0,349,353,3,66,33,0,350,353,
        3,80,40,0,351,353,3,84,42,0,352,348,1,0,0,0,352,349,1,0,0,0,352,
        350,1,0,0,0,352,351,1,0,0,0,353,55,1,0,0,0,354,355,5,70,0,0,355,
        358,5,57,0,0,356,359,3,4,2,0,357,359,3,22,11,0,358,356,1,0,0,0,358,
        357,1,0,0,0,359,360,1,0,0,0,360,361,5,59,0,0,361,57,1,0,0,0,362,
        363,5,2,0,0,363,364,5,57,0,0,364,365,3,60,30,0,365,366,5,59,0,0,
        366,367,5,25,0,0,367,368,3,64,32,0,368,377,1,0,0,0,369,370,5,2,0,
        0,370,371,5,58,0,0,371,372,3,60,30,0,372,373,5,60,0,0,373,374,5,
        25,0,0,374,375,3,64,32,0,375,377,1,0,0,0,376,362,1,0,0,0,376,369,
        1,0,0,0,377,59,1,0,0,0,378,383,3,62,31,0,379,380,5,46,0,0,380,382,
        3,62,31,0,381,379,1,0,0,0,382,385,1,0,0,0,383,381,1,0,0,0,383,384,
        1,0,0,0,384,61,1,0,0,0,385,383,1,0,0,0,386,387,3,44,22,0,387,63,
        1,0,0,0,388,389,3,42,21,0,389,65,1,0,0,0,390,392,5,31,0,0,391,393,
        3,68,34,0,392,391,1,0,0,0,392,393,1,0,0,0,393,394,1,0,0,0,394,395,
        5,13,0,0,395,67,1,0,0,0,396,399,3,70,35,0,397,398,5,47,0,0,398,400,
        3,74,37,0,399,397,1,0,0,0,399,400,1,0,0,0,400,403,1,0,0,0,401,403,
        3,74,37,0,402,396,1,0,0,0,402,401,1,0,0,0,403,69,1,0,0,0,404,409,
        3,72,36,0,405,406,5,47,0,0,406,408,3,72,36,0,407,405,1,0,0,0,408,
        411,1,0,0,0,409,407,1,0,0,0,409,410,1,0,0,0,410,71,1,0,0,0,411,409,
        1,0,0,0,412,413,3,104,52,0,413,414,5,48,0,0,414,415,3,42,21,0,415,
        73,1,0,0,0,416,417,5,5,0,0,417,418,3,76,38,0,418,419,5,25,0,0,419,
        424,3,78,39,0,420,421,5,47,0,0,421,423,3,78,39,0,422,420,1,0,0,0,
        423,426,1,0,0,0,424,422,1,0,0,0,424,425,1,0,0,0,425,75,1,0,0,0,426,
        424,1,0,0,0,427,428,3,4,2,0,428,429,5,48,0,0,429,430,3,50,25,0,430,
        433,1,0,0,0,431,433,3,50,25,0,432,427,1,0,0,0,432,431,1,0,0,0,433,
        77,1,0,0,0,434,435,3,106,53,0,435,436,5,48,0,0,436,437,5,55,0,0,
        437,438,3,68,34,0,438,439,5,56,0,0,439,79,1,0,0,0,440,441,5,33,0,
        0,441,442,5,25,0,0,442,443,3,82,41,0,443,81,1,0,0,0,444,445,3,44,
        22,0,445,83,1,0,0,0,446,447,5,14,0,0,447,448,5,25,0,0,448,451,3,
        42,21,0,449,451,5,14,0,0,450,446,1,0,0,0,450,449,1,0,0,0,451,85,
        1,0,0,0,452,453,5,61,0,0,453,454,3,50,25,0,454,87,1,0,0,0,455,456,
        5,38,0,0,456,461,3,90,45,0,457,458,5,47,0,0,458,460,3,90,45,0,459,
        457,1,0,0,0,460,463,1,0,0,0,461,459,1,0,0,0,461,462,1,0,0,0,462,
        464,1,0,0,0,463,461,1,0,0,0,464,465,5,47,0,0,465,89,1,0,0,0,466,
        467,3,104,52,0,467,468,5,48,0,0,468,469,3,42,21,0,469,91,1,0,0,0,
        470,471,3,94,47,0,471,472,5,47,0,0,472,93,1,0,0,0,473,476,3,96,48,
        0,474,476,3,108,54,0,475,473,1,0,0,0,475,474,1,0,0,0,476,95,1,0,
        0,0,477,478,5,28,0,0,478,480,3,4,2,0,479,481,3,98,49,0,480,479,1,
        0,0,0,480,481,1,0,0,0,481,482,1,0,0,0,482,483,5,47,0,0,483,484,3,
        6,3,0,484,97,1,0,0,0,485,486,5,55,0,0,486,491,3,100,50,0,487,488,
        5,47,0,0,488,490,3,100,50,0,489,487,1,0,0,0,490,493,1,0,0,0,491,
        489,1,0,0,0,491,492,1,0,0,0,492,494,1,0,0,0,493,491,1,0,0,0,494,
        495,5,56,0,0,495,99,1,0,0,0,496,504,3,102,51,0,497,498,5,38,0,0,
        498,504,3,102,51,0,499,500,5,16,0,0,500,504,3,102,51,0,501,502,5,
        28,0,0,502,504,3,102,51,0,503,496,1,0,0,0,503,497,1,0,0,0,503,499,
        1,0,0,0,503,501,1,0,0,0,504,101,1,0,0,0,505,506,3,104,52,0,506,507,
        5,48,0,0,507,508,3,50,25,0,508,103,1,0,0,0,509,514,3,4,2,0,510,511,
        5,46,0,0,511,513,3,4,2,0,512,510,1,0,0,0,513,516,1,0,0,0,514,512,
        1,0,0,0,514,515,1,0,0,0,515,105,1,0,0,0,516,514,1,0,0,0,517,522,
        3,20,10,0,518,519,5,46,0,0,519,521,3,20,10,0,520,518,1,0,0,0,521,
        524,1,0,0,0,522,520,1,0,0,0,522,523,1,0,0,0,523,107,1,0,0,0,524,
        522,1,0,0,0,525,526,5,16,0,0,526,528,3,4,2,0,527,529,3,98,49,0,528,
        527,1,0,0,0,528,529,1,0,0,0,529,530,1,0,0,0,530,531,5,48,0,0,531,
        532,3,110,55,0,532,533,5,47,0,0,533,534,3,6,3,0,534,109,1,0,0,0,
        535,536,3,50,25,0,536,111,1,0,0,0,537,538,3,12,6,0,538,539,5,48,
        0,0,539,540,3,114,57,0,540,543,1,0,0,0,541,543,3,114,57,0,542,537,
        1,0,0,0,542,541,1,0,0,0,543,113,1,0,0,0,544,547,3,116,58,0,545,547,
        3,162,81,0,546,544,1,0,0,0,546,545,1,0,0,0,547,115,1,0,0,0,548,553,
        3,118,59,0,549,553,3,150,75,0,550,553,3,156,78,0,551,553,3,158,79,
        0,552,548,1,0,0,0,552,549,1,0,0,0,552,550,1,0,0,0,552,551,1,0,0,
        0,553,117,1,0,0,0,554,555,3,120,60,0,555,556,5,45,0,0,556,557,3,
        122,61,0,557,119,1,0,0,0,558,559,5,62,0,0,559,562,3,4,2,0,560,562,
        3,4,2,0,561,558,1,0,0,0,561,560,1,0,0,0,562,590,1,0,0,0,563,564,
        5,57,0,0,564,569,3,122,61,0,565,566,5,46,0,0,566,568,3,122,61,0,
        567,565,1,0,0,0,568,571,1,0,0,0,569,567,1,0,0,0,569,570,1,0,0,0,
        570,572,1,0,0,0,571,569,1,0,0,0,572,573,5,59,0,0,573,589,1,0,0,0,
        574,575,5,58,0,0,575,580,3,122,61,0,576,577,5,46,0,0,577,579,3,122,
        61,0,578,576,1,0,0,0,579,582,1,0,0,0,580,578,1,0,0,0,580,581,1,0,
        0,0,581,583,1,0,0,0,582,580,1,0,0,0,583,584,5,60,0,0,584,589,1,0,
        0,0,585,586,5,63,0,0,586,589,3,4,2,0,587,589,5,61,0,0,588,563,1,
        0,0,0,588,574,1,0,0,0,588,585,1,0,0,0,588,587,1,0,0,0,589,592,1,
        0,0,0,590,588,1,0,0,0,590,591,1,0,0,0,591,121,1,0,0,0,592,590,1,
        0,0,0,593,597,3,126,63,0,594,595,3,124,62,0,595,596,3,122,61,0,596,
        598,1,0,0,0,597,594,1,0,0,0,597,598,1,0,0,0,598,123,1,0,0,0,599,
        600,7,3,0,0,600,125,1,0,0,0,601,605,3,130,65,0,602,603,3,128,64,
        0,603,604,3,126,63,0,604,606,1,0,0,0,605,602,1,0,0,0,605,606,1,0,
        0,0,606,127,1,0,0,0,607,608,7,4,0,0,608,129,1,0,0,0,609,613,3,134,
        67,0,610,611,3,132,66,0,611,612,3,130,65,0,612,614,1,0,0,0,613,610,
        1,0,0,0,613,614,1,0,0,0,614,131,1,0,0,0,615,616,7,5,0,0,616,133,
        1,0,0,0,617,619,7,0,0,0,618,617,1,0,0,0,618,619,1,0,0,0,619,620,
        1,0,0,0,620,621,3,136,68,0,621,135,1,0,0,0,622,634,3,120,60,0,623,
        624,5,55,0,0,624,625,3,122,61,0,625,626,5,56,0,0,626,634,1,0,0,0,
        627,634,3,140,70,0,628,634,3,138,69,0,629,634,3,144,72,0,630,631,
        5,24,0,0,631,634,3,136,68,0,632,634,3,30,15,0,633,622,1,0,0,0,633,
        623,1,0,0,0,633,627,1,0,0,0,633,628,1,0,0,0,633,629,1,0,0,0,633,
        630,1,0,0,0,633,632,1,0,0,0,634,137,1,0,0,0,635,640,3,22,11,0,636,
        640,3,18,9,0,637,640,3,32,16,0,638,640,5,23,0,0,639,635,1,0,0,0,
        639,636,1,0,0,0,639,637,1,0,0,0,639,638,1,0,0,0,640,139,1,0,0,0,
        641,642,3,4,2,0,642,643,5,55,0,0,643,644,3,142,71,0,644,645,5,56,
        0,0,645,141,1,0,0,0,646,651,3,152,76,0,647,648,5,46,0,0,648,650,
        3,152,76,0,649,647,1,0,0,0,650,653,1,0,0,0,651,649,1,0,0,0,651,652,
        1,0,0,0,652,143,1,0,0,0,653,651,1,0,0,0,654,655,5,57,0,0,655,656,
        3,146,73,0,656,657,5,59,0,0,657,663,1,0,0,0,658,659,5,58,0,0,659,
        660,3,146,73,0,660,661,5,60,0,0,661,663,1,0,0,0,662,654,1,0,0,0,
        662,658,1,0,0,0,663,145,1,0,0,0,664,669,3,148,74,0,665,666,5,46,
        0,0,666,668,3,148,74,0,667,665,1,0,0,0,668,671,1,0,0,0,669,667,1,
        0,0,0,669,670,1,0,0,0,670,674,1,0,0,0,671,669,1,0,0,0,672,674,1,
        0,0,0,673,664,1,0,0,0,673,672,1,0,0,0,674,147,1,0,0,0,675,678,3,
        122,61,0,676,677,5,64,0,0,677,679,3,122,61,0,678,676,1,0,0,0,678,
        679,1,0,0,0,679,149,1,0,0,0,680,685,3,4,2,0,681,682,5,55,0,0,682,
        683,3,142,71,0,683,684,5,56,0,0,684,686,1,0,0,0,685,681,1,0,0,0,
        685,686,1,0,0,0,686,151,1,0,0,0,687,691,3,122,61,0,688,690,3,154,
        77,0,689,688,1,0,0,0,690,693,1,0,0,0,691,689,1,0,0,0,691,692,1,0,
        0,0,692,153,1,0,0,0,693,691,1,0,0,0,694,695,5,48,0,0,695,696,3,122,
        61,0,696,155,1,0,0,0,697,698,5,17,0,0,698,699,3,12,6,0,699,157,1,
        0,0,0,700,701,1,0,0,0,701,159,1,0,0,0,702,703,1,0,0,0,703,161,1,
        0,0,0,704,709,3,164,82,0,705,709,3,168,84,0,706,709,3,176,88,0,707,
        709,3,190,95,0,708,704,1,0,0,0,708,705,1,0,0,0,708,706,1,0,0,0,708,
        707,1,0,0,0,709,163,1,0,0,0,710,711,5,3,0,0,711,712,3,166,83,0,712,
        713,5,13,0,0,713,165,1,0,0,0,714,719,3,112,56,0,715,716,5,47,0,0,
        716,718,3,112,56,0,717,715,1,0,0,0,718,721,1,0,0,0,719,717,1,0,0,
        0,719,720,1,0,0,0,720,167,1,0,0,0,721,719,1,0,0,0,722,725,3,170,
        85,0,723,725,3,172,86,0,724,722,1,0,0,0,724,723,1,0,0,0,725,169,
        1,0,0,0,726,727,5,18,0,0,727,728,3,122,61,0,728,729,5,34,0,0,729,
        732,3,112,56,0,730,731,5,12,0,0,731,733,3,112,56,0,732,730,1,0,0,
        0,732,733,1,0,0,0,733,171,1,0,0,0,734,735,5,5,0,0,735,736,3,122,
        61,0,736,737,5,25,0,0,737,742,3,174,87,0,738,739,5,47,0,0,739,741,
        3,174,87,0,740,738,1,0,0,0,741,744,1,0,0,0,742,740,1,0,0,0,742,743,
        1,0,0,0,743,748,1,0,0,0,744,742,1,0,0,0,745,746,5,47,0,0,746,747,
        5,12,0,0,747,749,3,166,83,0,748,745,1,0,0,0,748,749,1,0,0,0,749,
        750,1,0,0,0,750,751,5,13,0,0,751,173,1,0,0,0,752,753,3,106,53,0,
        753,754,5,48,0,0,754,755,3,112,56,0,755,175,1,0,0,0,756,760,3,178,
        89,0,757,760,3,180,90,0,758,760,3,182,91,0,759,756,1,0,0,0,759,757,
        1,0,0,0,759,758,1,0,0,0,760,177,1,0,0,0,761,762,5,39,0,0,762,763,
        3,122,61,0,763,764,5,10,0,0,764,765,3,112,56,0,765,179,1,0,0,0,766,
        767,5,32,0,0,767,768,3,166,83,0,768,769,5,37,0,0,769,770,3,122,61,
        0,770,181,1,0,0,0,771,772,5,15,0,0,772,773,3,4,2,0,773,774,5,45,
        0,0,774,775,3,184,92,0,775,776,5,10,0,0,776,777,3,112,56,0,777,183,
        1,0,0,0,778,779,3,186,93,0,779,780,7,6,0,0,780,781,3,188,94,0,781,
        185,1,0,0,0,782,783,3,122,61,0,783,187,1,0,0,0,784,785,3,122,61,
        0,785,189,1,0,0,0,786,787,5,40,0,0,787,788,3,192,96,0,788,789,5,
        10,0,0,789,790,3,112,56,0,790,191,1,0,0,0,791,796,3,120,60,0,792,
        793,5,46,0,0,793,795,3,120,60,0,794,792,1,0,0,0,795,798,1,0,0,0,
        796,794,1,0,0,0,796,797,1,0,0,0,797,193,1,0,0,0,798,796,1,0,0,0,
        65,196,208,216,227,229,244,257,278,282,300,307,311,318,323,329,341,
        346,352,358,376,383,392,399,402,409,424,432,450,461,475,480,491,
        503,514,522,528,542,546,552,561,569,580,588,590,597,605,613,618,
        633,639,651,662,669,673,678,685,691,708,719,724,732,742,748,759,
        796
    ]

class PascalParser ( Parser ):

    grammarFileName = "Pascal.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'AND'", "'ARRAY'", "'BEGIN'", "'BOOLEAN'", 
                     "'CASE'", "'CHAR'", "'CHR'", "'CONST'", "'DIV'", "'DO'", 
                     "'DOWNTO'", "'ELSE'", "'END'", "'FILE'", "'FOR'", "'FUNCTION'", 
                     "'GOTO'", "'IF'", "'IN'", "'INTEGER'", "'LABEL'", "'MOD'", 
                     "'NIL'", "'NOT'", "'OF'", "'OR'", "'PACKED'", "'PROCEDURE'", 
                     "'PROGRAM'", "'REAL'", "'RECORD'", "'REPEAT'", "'SET'", 
                     "'THEN'", "'TO'", "'TYPE'", "'UNTIL'", "'VAR'", "'WHILE'", 
                     "'WITH'", "'+'", "'-'", "'*'", "'/'", "':='", "','", 
                     "';'", "':'", "'='", "'<>'", "'<'", "'<='", "'>='", 
                     "'>'", "'('", "')'", "'['", "'(.'", "']'", "'.)'", 
                     "'^'", "'@'", "'.'", "'..'", "'{'", "'}'", "'UNIT'", 
                     "'INTERFACE'", "'USES'", "'STRING'", "'IMPLEMENTATION'", 
                     "'TRUE'", "'FALSE'" ]

    symbolicNames = [ "<INVALID>", "AND", "ARRAY", "BEGIN", "BOOLEAN", "CASE", 
                      "CHAR", "CHR", "CONST", "DIV", "DO", "DOWNTO", "ELSE", 
                      "END", "FILE", "FOR", "FUNCTION", "GOTO", "IF", "IN", 
                      "INTEGER", "LABEL", "MOD", "NIL", "NOT", "OF", "OR", 
                      "PACKED", "PROCEDURE", "PROGRAM", "REAL", "RECORD", 
                      "REPEAT", "SET", "THEN", "TO", "TYPE", "UNTIL", "VAR", 
                      "WHILE", "WITH", "PLUS", "MINUS", "STAR", "SLASH", 
                      "ASSIGN", "COMMA", "SEMI", "COLON", "EQUAL", "NOT_EQUAL", 
                      "LT", "LE", "GE", "GT", "LPAREN", "RPAREN", "LBRACK", 
                      "LBRACK2", "RBRACK", "RBRACK2", "POINTER", "AT", "DOT", 
                      "DOTDOT", "LCURLY", "RCURLY", "UNIT", "INTERFACE", 
                      "USES", "STRING", "IMPLEMENTATION", "TRUE", "FALSE", 
                      "WS", "COMMENT_1", "COMMENT_2", "IDENT", "STRING_LITERAL", 
                      "NUM_INT", "NUM_REAL" ]

    RULE_program = 0
    RULE_programHeading = 1
    RULE_identifier = 2
    RULE_block = 3
    RULE_usesUnitsPart = 4
    RULE_labelDeclarationPart = 5
    RULE_label = 6
    RULE_constantDefinitionPart = 7
    RULE_constantDefinition = 8
    RULE_constantChr = 9
    RULE_constant = 10
    RULE_unsignedNumber = 11
    RULE_unsignedInteger = 12
    RULE_unsignedReal = 13
    RULE_sign = 14
    RULE_bool_ = 15
    RULE_string = 16
    RULE_typeDefinitionPart = 17
    RULE_typeDefinition = 18
    RULE_functionType = 19
    RULE_procedureType = 20
    RULE_type_ = 21
    RULE_simpleType = 22
    RULE_scalarType = 23
    RULE_subrangeType = 24
    RULE_typeIdentifier = 25
    RULE_structuredType = 26
    RULE_unpackedStructuredType = 27
    RULE_stringtype = 28
    RULE_arrayType = 29
    RULE_typeList = 30
    RULE_indexType = 31
    RULE_componentType = 32
    RULE_recordType = 33
    RULE_fieldList = 34
    RULE_fixedPart = 35
    RULE_recordSection = 36
    RULE_variantPart = 37
    RULE_tag = 38
    RULE_variant = 39
    RULE_setType = 40
    RULE_baseType = 41
    RULE_fileType = 42
    RULE_pointerType = 43
    RULE_variableDeclarationPart = 44
    RULE_variableDeclaration = 45
    RULE_procedureAndFunctionDeclarationPart = 46
    RULE_procedureOrFunctionDeclaration = 47
    RULE_procedureDeclaration = 48
    RULE_formalParameterList = 49
    RULE_formalParameterSection = 50
    RULE_parameterGroup = 51
    RULE_identifierList = 52
    RULE_constList = 53
    RULE_functionDeclaration = 54
    RULE_resultType = 55
    RULE_statement = 56
    RULE_unlabelledStatement = 57
    RULE_simpleStatement = 58
    RULE_assignmentStatement = 59
    RULE_variable = 60
    RULE_expression = 61
    RULE_relationaloperator = 62
    RULE_simpleExpression = 63
    RULE_additiveoperator = 64
    RULE_term = 65
    RULE_multiplicativeoperator = 66
    RULE_signedFactor = 67
    RULE_factor = 68
    RULE_unsignedConstant = 69
    RULE_functionDesignator = 70
    RULE_parameterList = 71
    RULE_set_ = 72
    RULE_elementList = 73
    RULE_element = 74
    RULE_procedureStatement = 75
    RULE_actualParameter = 76
    RULE_parameterwidth = 77
    RULE_gotoStatement = 78
    RULE_emptyStatement_ = 79
    RULE_empty_ = 80
    RULE_structuredStatement = 81
    RULE_compoundStatement = 82
    RULE_statements = 83
    RULE_conditionalStatement = 84
    RULE_ifStatement = 85
    RULE_caseStatement = 86
    RULE_caseListElement = 87
    RULE_repetetiveStatement = 88
    RULE_whileStatement = 89
    RULE_repeatStatement = 90
    RULE_forStatement = 91
    RULE_forList = 92
    RULE_initialValue = 93
    RULE_finalValue = 94
    RULE_withStatement = 95
    RULE_recordVariableList = 96

    ruleNames =  [ "program", "programHeading", "identifier", "block", "usesUnitsPart", 
                   "labelDeclarationPart", "label", "constantDefinitionPart", 
                   "constantDefinition", "constantChr", "constant", "unsignedNumber", 
                   "unsignedInteger", "unsignedReal", "sign", "bool_", "string", 
                   "typeDefinitionPart", "typeDefinition", "functionType", 
                   "procedureType", "type_", "simpleType", "scalarType", 
                   "subrangeType", "typeIdentifier", "structuredType", "unpackedStructuredType", 
                   "stringtype", "arrayType", "typeList", "indexType", "componentType", 
                   "recordType", "fieldList", "fixedPart", "recordSection", 
                   "variantPart", "tag", "variant", "setType", "baseType", 
                   "fileType", "pointerType", "variableDeclarationPart", 
                   "variableDeclaration", "procedureAndFunctionDeclarationPart", 
                   "procedureOrFunctionDeclaration", "procedureDeclaration", 
                   "formalParameterList", "formalParameterSection", "parameterGroup", 
                   "identifierList", "constList", "functionDeclaration", 
                   "resultType", "statement", "unlabelledStatement", "simpleStatement", 
                   "assignmentStatement", "variable", "expression", "relationaloperator", 
                   "simpleExpression", "additiveoperator", "term", "multiplicativeoperator", 
                   "signedFactor", "factor", "unsignedConstant", "functionDesignator", 
                   "parameterList", "set_", "elementList", "element", "procedureStatement", 
                   "actualParameter", "parameterwidth", "gotoStatement", 
                   "emptyStatement_", "empty_", "structuredStatement", "compoundStatement", 
                   "statements", "conditionalStatement", "ifStatement", 
                   "caseStatement", "caseListElement", "repetetiveStatement", 
                   "whileStatement", "repeatStatement", "forStatement", 
                   "forList", "initialValue", "finalValue", "withStatement", 
                   "recordVariableList" ]

    EOF = Token.EOF
    AND=1
    ARRAY=2
    BEGIN=3
    BOOLEAN=4
    CASE=5
    CHAR=6
    CHR=7
    CONST=8
    DIV=9
    DO=10
    DOWNTO=11
    ELSE=12
    END=13
    FILE=14
    FOR=15
    FUNCTION=16
    GOTO=17
    IF=18
    IN=19
    INTEGER=20
    LABEL=21
    MOD=22
    NIL=23
    NOT=24
    OF=25
    OR=26
    PACKED=27
    PROCEDURE=28
    PROGRAM=29
    REAL=30
    RECORD=31
    REPEAT=32
    SET=33
    THEN=34
    TO=35
    TYPE=36
    UNTIL=37
    VAR=38
    WHILE=39
    WITH=40
    PLUS=41
    MINUS=42
    STAR=43
    SLASH=44
    ASSIGN=45
    COMMA=46
    SEMI=47
    COLON=48
    EQUAL=49
    NOT_EQUAL=50
    LT=51
    LE=52
    GE=53
    GT=54
    LPAREN=55
    RPAREN=56
    LBRACK=57
    LBRACK2=58
    RBRACK=59
    RBRACK2=60
    POINTER=61
    AT=62
    DOT=63
    DOTDOT=64
    LCURLY=65
    RCURLY=66
    UNIT=67
    INTERFACE=68
    USES=69
    STRING=70
    IMPLEMENTATION=71
    TRUE=72
    FALSE=73
    WS=74
    COMMENT_1=75
    COMMENT_2=76
    IDENT=77
    STRING_LITERAL=78
    NUM_INT=79
    NUM_REAL=80

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def programHeading(self):
            return self.getTypedRuleContext(PascalParser.ProgramHeadingContext,0)


        def block(self):
            return self.getTypedRuleContext(PascalParser.BlockContext,0)


        def DOT(self):
            return self.getToken(PascalParser.DOT, 0)

        def EOF(self):
            return self.getToken(PascalParser.EOF, 0)

        def INTERFACE(self):
            return self.getToken(PascalParser.INTERFACE, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_program

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProgram" ):
                return visitor.visitProgram(self)
            else:
                return visitor.visitChildren(self)




    def program(self):

        localctx = PascalParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 194
            self.programHeading()
            self.state = 196
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==68:
                self.state = 195
                self.match(PascalParser.INTERFACE)


            self.state = 198
            self.block()
            self.state = 199
            self.match(PascalParser.DOT)
            self.state = 200
            self.match(PascalParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ProgramHeadingContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PROGRAM(self):
            return self.getToken(PascalParser.PROGRAM, 0)

        def identifier(self):
            return self.getTypedRuleContext(PascalParser.IdentifierContext,0)


        def SEMI(self):
            return self.getToken(PascalParser.SEMI, 0)

        def LPAREN(self):
            return self.getToken(PascalParser.LPAREN, 0)

        def identifierList(self):
            return self.getTypedRuleContext(PascalParser.IdentifierListContext,0)


        def RPAREN(self):
            return self.getToken(PascalParser.RPAREN, 0)

        def UNIT(self):
            return self.getToken(PascalParser.UNIT, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_programHeading

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProgramHeading" ):
                return visitor.visitProgramHeading(self)
            else:
                return visitor.visitChildren(self)




    def programHeading(self):

        localctx = PascalParser.ProgramHeadingContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_programHeading)
        self._la = 0 # Token type
        try:
            self.state = 216
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [29]:
                self.enterOuterAlt(localctx, 1)
                self.state = 202
                self.match(PascalParser.PROGRAM)
                self.state = 203
                self.identifier()
                self.state = 208
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==55:
                    self.state = 204
                    self.match(PascalParser.LPAREN)
                    self.state = 205
                    self.identifierList()
                    self.state = 206
                    self.match(PascalParser.RPAREN)


                self.state = 210
                self.match(PascalParser.SEMI)
                pass
            elif token in [67]:
                self.enterOuterAlt(localctx, 2)
                self.state = 212
                self.match(PascalParser.UNIT)
                self.state = 213
                self.identifier()
                self.state = 214
                self.match(PascalParser.SEMI)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IdentifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENT(self):
            return self.getToken(PascalParser.IDENT, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_identifier

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIdentifier" ):
                return visitor.visitIdentifier(self)
            else:
                return visitor.visitChildren(self)




    def identifier(self):

        localctx = PascalParser.IdentifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_identifier)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 218
            self.match(PascalParser.IDENT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BlockContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def compoundStatement(self):
            return self.getTypedRuleContext(PascalParser.CompoundStatementContext,0)


        def labelDeclarationPart(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PascalParser.LabelDeclarationPartContext)
            else:
                return self.getTypedRuleContext(PascalParser.LabelDeclarationPartContext,i)


        def constantDefinitionPart(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PascalParser.ConstantDefinitionPartContext)
            else:
                return self.getTypedRuleContext(PascalParser.ConstantDefinitionPartContext,i)


        def typeDefinitionPart(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PascalParser.TypeDefinitionPartContext)
            else:
                return self.getTypedRuleContext(PascalParser.TypeDefinitionPartContext,i)


        def variableDeclarationPart(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PascalParser.VariableDeclarationPartContext)
            else:
                return self.getTypedRuleContext(PascalParser.VariableDeclarationPartContext,i)


        def procedureAndFunctionDeclarationPart(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PascalParser.ProcedureAndFunctionDeclarationPartContext)
            else:
                return self.getTypedRuleContext(PascalParser.ProcedureAndFunctionDeclarationPartContext,i)


        def usesUnitsPart(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PascalParser.UsesUnitsPartContext)
            else:
                return self.getTypedRuleContext(PascalParser.UsesUnitsPartContext,i)


        def IMPLEMENTATION(self, i:int=None):
            if i is None:
                return self.getTokens(PascalParser.IMPLEMENTATION)
            else:
                return self.getToken(PascalParser.IMPLEMENTATION, i)

        def getRuleIndex(self):
            return PascalParser.RULE_block

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBlock" ):
                return visitor.visitBlock(self)
            else:
                return visitor.visitChildren(self)




    def block(self):

        localctx = PascalParser.BlockContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_block)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 229
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while ((((_la - 8)) & ~0x3f) == 0 and ((1 << (_la - 8)) & -6917529026297847551) != 0):
                self.state = 227
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [21]:
                    self.state = 220
                    self.labelDeclarationPart()
                    pass
                elif token in [8]:
                    self.state = 221
                    self.constantDefinitionPart()
                    pass
                elif token in [36]:
                    self.state = 222
                    self.typeDefinitionPart()
                    pass
                elif token in [38]:
                    self.state = 223
                    self.variableDeclarationPart()
                    pass
                elif token in [16, 28]:
                    self.state = 224
                    self.procedureAndFunctionDeclarationPart()
                    pass
                elif token in [69]:
                    self.state = 225
                    self.usesUnitsPart()
                    pass
                elif token in [71]:
                    self.state = 226
                    self.match(PascalParser.IMPLEMENTATION)
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 231
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 232
            self.compoundStatement()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UsesUnitsPartContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def USES(self):
            return self.getToken(PascalParser.USES, 0)

        def identifierList(self):
            return self.getTypedRuleContext(PascalParser.IdentifierListContext,0)


        def SEMI(self):
            return self.getToken(PascalParser.SEMI, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_usesUnitsPart

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUsesUnitsPart" ):
                return visitor.visitUsesUnitsPart(self)
            else:
                return visitor.visitChildren(self)




    def usesUnitsPart(self):

        localctx = PascalParser.UsesUnitsPartContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_usesUnitsPart)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 234
            self.match(PascalParser.USES)
            self.state = 235
            self.identifierList()
            self.state = 236
            self.match(PascalParser.SEMI)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LabelDeclarationPartContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LABEL(self):
            return self.getToken(PascalParser.LABEL, 0)

        def label(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PascalParser.LabelContext)
            else:
                return self.getTypedRuleContext(PascalParser.LabelContext,i)


        def SEMI(self):
            return self.getToken(PascalParser.SEMI, 0)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(PascalParser.COMMA)
            else:
                return self.getToken(PascalParser.COMMA, i)

        def getRuleIndex(self):
            return PascalParser.RULE_labelDeclarationPart

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLabelDeclarationPart" ):
                return visitor.visitLabelDeclarationPart(self)
            else:
                return visitor.visitChildren(self)




    def labelDeclarationPart(self):

        localctx = PascalParser.LabelDeclarationPartContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_labelDeclarationPart)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 238
            self.match(PascalParser.LABEL)
            self.state = 239
            self.label()
            self.state = 244
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==46:
                self.state = 240
                self.match(PascalParser.COMMA)
                self.state = 241
                self.label()
                self.state = 246
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 247
            self.match(PascalParser.SEMI)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LabelContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def unsignedInteger(self):
            return self.getTypedRuleContext(PascalParser.UnsignedIntegerContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_label

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLabel" ):
                return visitor.visitLabel(self)
            else:
                return visitor.visitChildren(self)




    def label(self):

        localctx = PascalParser.LabelContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_label)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 249
            self.unsignedInteger()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstantDefinitionPartContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CONST(self):
            return self.getToken(PascalParser.CONST, 0)

        def constantDefinition(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PascalParser.ConstantDefinitionContext)
            else:
                return self.getTypedRuleContext(PascalParser.ConstantDefinitionContext,i)


        def SEMI(self, i:int=None):
            if i is None:
                return self.getTokens(PascalParser.SEMI)
            else:
                return self.getToken(PascalParser.SEMI, i)

        def getRuleIndex(self):
            return PascalParser.RULE_constantDefinitionPart

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitConstantDefinitionPart" ):
                return visitor.visitConstantDefinitionPart(self)
            else:
                return visitor.visitChildren(self)




    def constantDefinitionPart(self):

        localctx = PascalParser.ConstantDefinitionPartContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_constantDefinitionPart)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 251
            self.match(PascalParser.CONST)
            self.state = 255 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 252
                self.constantDefinition()
                self.state = 253
                self.match(PascalParser.SEMI)
                self.state = 257 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==77):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstantDefinitionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(PascalParser.IdentifierContext,0)


        def EQUAL(self):
            return self.getToken(PascalParser.EQUAL, 0)

        def constant(self):
            return self.getTypedRuleContext(PascalParser.ConstantContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_constantDefinition

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitConstantDefinition" ):
                return visitor.visitConstantDefinition(self)
            else:
                return visitor.visitChildren(self)




    def constantDefinition(self):

        localctx = PascalParser.ConstantDefinitionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_constantDefinition)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 259
            self.identifier()
            self.state = 260
            self.match(PascalParser.EQUAL)
            self.state = 261
            self.constant()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstantChrContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CHR(self):
            return self.getToken(PascalParser.CHR, 0)

        def LPAREN(self):
            return self.getToken(PascalParser.LPAREN, 0)

        def unsignedInteger(self):
            return self.getTypedRuleContext(PascalParser.UnsignedIntegerContext,0)


        def RPAREN(self):
            return self.getToken(PascalParser.RPAREN, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_constantChr

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitConstantChr" ):
                return visitor.visitConstantChr(self)
            else:
                return visitor.visitChildren(self)




    def constantChr(self):

        localctx = PascalParser.ConstantChrContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_constantChr)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 263
            self.match(PascalParser.CHR)
            self.state = 264
            self.match(PascalParser.LPAREN)
            self.state = 265
            self.unsignedInteger()
            self.state = 266
            self.match(PascalParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstantContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def unsignedNumber(self):
            return self.getTypedRuleContext(PascalParser.UnsignedNumberContext,0)


        def sign(self):
            return self.getTypedRuleContext(PascalParser.SignContext,0)


        def identifier(self):
            return self.getTypedRuleContext(PascalParser.IdentifierContext,0)


        def string(self):
            return self.getTypedRuleContext(PascalParser.StringContext,0)


        def constantChr(self):
            return self.getTypedRuleContext(PascalParser.ConstantChrContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_constant

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitConstant" ):
                return visitor.visitConstant(self)
            else:
                return visitor.visitChildren(self)




    def constant(self):

        localctx = PascalParser.ConstantContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_constant)
        try:
            self.state = 278
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,7,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 268
                self.unsignedNumber()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 269
                self.sign()
                self.state = 270
                self.unsignedNumber()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 272
                self.identifier()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 273
                self.sign()
                self.state = 274
                self.identifier()
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 276
                self.string()
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 277
                self.constantChr()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UnsignedNumberContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def unsignedInteger(self):
            return self.getTypedRuleContext(PascalParser.UnsignedIntegerContext,0)


        def unsignedReal(self):
            return self.getTypedRuleContext(PascalParser.UnsignedRealContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_unsignedNumber

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnsignedNumber" ):
                return visitor.visitUnsignedNumber(self)
            else:
                return visitor.visitChildren(self)




    def unsignedNumber(self):

        localctx = PascalParser.UnsignedNumberContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_unsignedNumber)
        try:
            self.state = 282
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [79]:
                self.enterOuterAlt(localctx, 1)
                self.state = 280
                self.unsignedInteger()
                pass
            elif token in [80]:
                self.enterOuterAlt(localctx, 2)
                self.state = 281
                self.unsignedReal()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UnsignedIntegerContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NUM_INT(self):
            return self.getToken(PascalParser.NUM_INT, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_unsignedInteger

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnsignedInteger" ):
                return visitor.visitUnsignedInteger(self)
            else:
                return visitor.visitChildren(self)




    def unsignedInteger(self):

        localctx = PascalParser.UnsignedIntegerContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_unsignedInteger)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 284
            self.match(PascalParser.NUM_INT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UnsignedRealContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NUM_REAL(self):
            return self.getToken(PascalParser.NUM_REAL, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_unsignedReal

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnsignedReal" ):
                return visitor.visitUnsignedReal(self)
            else:
                return visitor.visitChildren(self)




    def unsignedReal(self):

        localctx = PascalParser.UnsignedRealContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_unsignedReal)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 286
            self.match(PascalParser.NUM_REAL)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SignContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PLUS(self):
            return self.getToken(PascalParser.PLUS, 0)

        def MINUS(self):
            return self.getToken(PascalParser.MINUS, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_sign

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSign" ):
                return visitor.visitSign(self)
            else:
                return visitor.visitChildren(self)




    def sign(self):

        localctx = PascalParser.SignContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_sign)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 288
            _la = self._input.LA(1)
            if not(_la==41 or _la==42):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Bool_Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TRUE(self):
            return self.getToken(PascalParser.TRUE, 0)

        def FALSE(self):
            return self.getToken(PascalParser.FALSE, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_bool_

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBool_" ):
                return visitor.visitBool_(self)
            else:
                return visitor.visitChildren(self)




    def bool_(self):

        localctx = PascalParser.Bool_Context(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_bool_)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 290
            _la = self._input.LA(1)
            if not(_la==72 or _la==73):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StringContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def STRING_LITERAL(self):
            return self.getToken(PascalParser.STRING_LITERAL, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_string

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitString" ):
                return visitor.visitString(self)
            else:
                return visitor.visitChildren(self)




    def string(self):

        localctx = PascalParser.StringContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_string)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 292
            self.match(PascalParser.STRING_LITERAL)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeDefinitionPartContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TYPE(self):
            return self.getToken(PascalParser.TYPE, 0)

        def typeDefinition(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PascalParser.TypeDefinitionContext)
            else:
                return self.getTypedRuleContext(PascalParser.TypeDefinitionContext,i)


        def SEMI(self, i:int=None):
            if i is None:
                return self.getTokens(PascalParser.SEMI)
            else:
                return self.getToken(PascalParser.SEMI, i)

        def getRuleIndex(self):
            return PascalParser.RULE_typeDefinitionPart

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTypeDefinitionPart" ):
                return visitor.visitTypeDefinitionPart(self)
            else:
                return visitor.visitChildren(self)




    def typeDefinitionPart(self):

        localctx = PascalParser.TypeDefinitionPartContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_typeDefinitionPart)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 294
            self.match(PascalParser.TYPE)
            self.state = 298 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 295
                self.typeDefinition()
                self.state = 296
                self.match(PascalParser.SEMI)
                self.state = 300 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==77):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeDefinitionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(PascalParser.IdentifierContext,0)


        def EQUAL(self):
            return self.getToken(PascalParser.EQUAL, 0)

        def type_(self):
            return self.getTypedRuleContext(PascalParser.Type_Context,0)


        def functionType(self):
            return self.getTypedRuleContext(PascalParser.FunctionTypeContext,0)


        def procedureType(self):
            return self.getTypedRuleContext(PascalParser.ProcedureTypeContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_typeDefinition

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTypeDefinition" ):
                return visitor.visitTypeDefinition(self)
            else:
                return visitor.visitChildren(self)




    def typeDefinition(self):

        localctx = PascalParser.TypeDefinitionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_typeDefinition)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 302
            self.identifier()
            self.state = 303
            self.match(PascalParser.EQUAL)
            self.state = 307
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [2, 4, 6, 7, 14, 20, 27, 30, 31, 33, 41, 42, 55, 61, 70, 77, 78, 79, 80]:
                self.state = 304
                self.type_()
                pass
            elif token in [16]:
                self.state = 305
                self.functionType()
                pass
            elif token in [28]:
                self.state = 306
                self.procedureType()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FUNCTION(self):
            return self.getToken(PascalParser.FUNCTION, 0)

        def COLON(self):
            return self.getToken(PascalParser.COLON, 0)

        def resultType(self):
            return self.getTypedRuleContext(PascalParser.ResultTypeContext,0)


        def formalParameterList(self):
            return self.getTypedRuleContext(PascalParser.FormalParameterListContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_functionType

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFunctionType" ):
                return visitor.visitFunctionType(self)
            else:
                return visitor.visitChildren(self)




    def functionType(self):

        localctx = PascalParser.FunctionTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_functionType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 309
            self.match(PascalParser.FUNCTION)
            self.state = 311
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==55:
                self.state = 310
                self.formalParameterList()


            self.state = 313
            self.match(PascalParser.COLON)
            self.state = 314
            self.resultType()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ProcedureTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PROCEDURE(self):
            return self.getToken(PascalParser.PROCEDURE, 0)

        def formalParameterList(self):
            return self.getTypedRuleContext(PascalParser.FormalParameterListContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_procedureType

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProcedureType" ):
                return visitor.visitProcedureType(self)
            else:
                return visitor.visitChildren(self)




    def procedureType(self):

        localctx = PascalParser.ProcedureTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_procedureType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 316
            self.match(PascalParser.PROCEDURE)
            self.state = 318
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==55:
                self.state = 317
                self.formalParameterList()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Type_Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def simpleType(self):
            return self.getTypedRuleContext(PascalParser.SimpleTypeContext,0)


        def structuredType(self):
            return self.getTypedRuleContext(PascalParser.StructuredTypeContext,0)


        def pointerType(self):
            return self.getTypedRuleContext(PascalParser.PointerTypeContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_type_

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitType_" ):
                return visitor.visitType_(self)
            else:
                return visitor.visitChildren(self)




    def type_(self):

        localctx = PascalParser.Type_Context(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_type_)
        try:
            self.state = 323
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [4, 6, 7, 20, 30, 41, 42, 55, 70, 77, 78, 79, 80]:
                self.enterOuterAlt(localctx, 1)
                self.state = 320
                self.simpleType()
                pass
            elif token in [2, 14, 27, 31, 33]:
                self.enterOuterAlt(localctx, 2)
                self.state = 321
                self.structuredType()
                pass
            elif token in [61]:
                self.enterOuterAlt(localctx, 3)
                self.state = 322
                self.pointerType()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SimpleTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def scalarType(self):
            return self.getTypedRuleContext(PascalParser.ScalarTypeContext,0)


        def subrangeType(self):
            return self.getTypedRuleContext(PascalParser.SubrangeTypeContext,0)


        def typeIdentifier(self):
            return self.getTypedRuleContext(PascalParser.TypeIdentifierContext,0)


        def stringtype(self):
            return self.getTypedRuleContext(PascalParser.StringtypeContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_simpleType

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSimpleType" ):
                return visitor.visitSimpleType(self)
            else:
                return visitor.visitChildren(self)




    def simpleType(self):

        localctx = PascalParser.SimpleTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_simpleType)
        try:
            self.state = 329
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,14,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 325
                self.scalarType()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 326
                self.subrangeType()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 327
                self.typeIdentifier()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 328
                self.stringtype()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ScalarTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LPAREN(self):
            return self.getToken(PascalParser.LPAREN, 0)

        def identifierList(self):
            return self.getTypedRuleContext(PascalParser.IdentifierListContext,0)


        def RPAREN(self):
            return self.getToken(PascalParser.RPAREN, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_scalarType

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitScalarType" ):
                return visitor.visitScalarType(self)
            else:
                return visitor.visitChildren(self)




    def scalarType(self):

        localctx = PascalParser.ScalarTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_scalarType)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 331
            self.match(PascalParser.LPAREN)
            self.state = 332
            self.identifierList()
            self.state = 333
            self.match(PascalParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SubrangeTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def constant(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PascalParser.ConstantContext)
            else:
                return self.getTypedRuleContext(PascalParser.ConstantContext,i)


        def DOTDOT(self):
            return self.getToken(PascalParser.DOTDOT, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_subrangeType

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSubrangeType" ):
                return visitor.visitSubrangeType(self)
            else:
                return visitor.visitChildren(self)




    def subrangeType(self):

        localctx = PascalParser.SubrangeTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_subrangeType)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 335
            self.constant()
            self.state = 336
            self.match(PascalParser.DOTDOT)
            self.state = 337
            self.constant()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeIdentifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(PascalParser.IdentifierContext,0)


        def CHAR(self):
            return self.getToken(PascalParser.CHAR, 0)

        def BOOLEAN(self):
            return self.getToken(PascalParser.BOOLEAN, 0)

        def INTEGER(self):
            return self.getToken(PascalParser.INTEGER, 0)

        def REAL(self):
            return self.getToken(PascalParser.REAL, 0)

        def STRING(self):
            return self.getToken(PascalParser.STRING, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_typeIdentifier

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTypeIdentifier" ):
                return visitor.visitTypeIdentifier(self)
            else:
                return visitor.visitChildren(self)




    def typeIdentifier(self):

        localctx = PascalParser.TypeIdentifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_typeIdentifier)
        self._la = 0 # Token type
        try:
            self.state = 341
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [77]:
                self.enterOuterAlt(localctx, 1)
                self.state = 339
                self.identifier()
                pass
            elif token in [4, 6, 20, 30, 70]:
                self.enterOuterAlt(localctx, 2)
                self.state = 340
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 1074790480) != 0) or _la==70):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StructuredTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PACKED(self):
            return self.getToken(PascalParser.PACKED, 0)

        def unpackedStructuredType(self):
            return self.getTypedRuleContext(PascalParser.UnpackedStructuredTypeContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_structuredType

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStructuredType" ):
                return visitor.visitStructuredType(self)
            else:
                return visitor.visitChildren(self)




    def structuredType(self):

        localctx = PascalParser.StructuredTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_structuredType)
        try:
            self.state = 346
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [27]:
                self.enterOuterAlt(localctx, 1)
                self.state = 343
                self.match(PascalParser.PACKED)
                self.state = 344
                self.unpackedStructuredType()
                pass
            elif token in [2, 14, 31, 33]:
                self.enterOuterAlt(localctx, 2)
                self.state = 345
                self.unpackedStructuredType()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UnpackedStructuredTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def arrayType(self):
            return self.getTypedRuleContext(PascalParser.ArrayTypeContext,0)


        def recordType(self):
            return self.getTypedRuleContext(PascalParser.RecordTypeContext,0)


        def setType(self):
            return self.getTypedRuleContext(PascalParser.SetTypeContext,0)


        def fileType(self):
            return self.getTypedRuleContext(PascalParser.FileTypeContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_unpackedStructuredType

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnpackedStructuredType" ):
                return visitor.visitUnpackedStructuredType(self)
            else:
                return visitor.visitChildren(self)




    def unpackedStructuredType(self):

        localctx = PascalParser.UnpackedStructuredTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_unpackedStructuredType)
        try:
            self.state = 352
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [2]:
                self.enterOuterAlt(localctx, 1)
                self.state = 348
                self.arrayType()
                pass
            elif token in [31]:
                self.enterOuterAlt(localctx, 2)
                self.state = 349
                self.recordType()
                pass
            elif token in [33]:
                self.enterOuterAlt(localctx, 3)
                self.state = 350
                self.setType()
                pass
            elif token in [14]:
                self.enterOuterAlt(localctx, 4)
                self.state = 351
                self.fileType()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StringtypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def STRING(self):
            return self.getToken(PascalParser.STRING, 0)

        def LBRACK(self):
            return self.getToken(PascalParser.LBRACK, 0)

        def RBRACK(self):
            return self.getToken(PascalParser.RBRACK, 0)

        def identifier(self):
            return self.getTypedRuleContext(PascalParser.IdentifierContext,0)


        def unsignedNumber(self):
            return self.getTypedRuleContext(PascalParser.UnsignedNumberContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_stringtype

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStringtype" ):
                return visitor.visitStringtype(self)
            else:
                return visitor.visitChildren(self)




    def stringtype(self):

        localctx = PascalParser.StringtypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_stringtype)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 354
            self.match(PascalParser.STRING)
            self.state = 355
            self.match(PascalParser.LBRACK)
            self.state = 358
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [77]:
                self.state = 356
                self.identifier()
                pass
            elif token in [79, 80]:
                self.state = 357
                self.unsignedNumber()
                pass
            else:
                raise NoViableAltException(self)

            self.state = 360
            self.match(PascalParser.RBRACK)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArrayTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ARRAY(self):
            return self.getToken(PascalParser.ARRAY, 0)

        def LBRACK(self):
            return self.getToken(PascalParser.LBRACK, 0)

        def typeList(self):
            return self.getTypedRuleContext(PascalParser.TypeListContext,0)


        def RBRACK(self):
            return self.getToken(PascalParser.RBRACK, 0)

        def OF(self):
            return self.getToken(PascalParser.OF, 0)

        def componentType(self):
            return self.getTypedRuleContext(PascalParser.ComponentTypeContext,0)


        def LBRACK2(self):
            return self.getToken(PascalParser.LBRACK2, 0)

        def RBRACK2(self):
            return self.getToken(PascalParser.RBRACK2, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_arrayType

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitArrayType" ):
                return visitor.visitArrayType(self)
            else:
                return visitor.visitChildren(self)




    def arrayType(self):

        localctx = PascalParser.ArrayTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_arrayType)
        try:
            self.state = 376
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,19,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 362
                self.match(PascalParser.ARRAY)
                self.state = 363
                self.match(PascalParser.LBRACK)
                self.state = 364
                self.typeList()
                self.state = 365
                self.match(PascalParser.RBRACK)
                self.state = 366
                self.match(PascalParser.OF)
                self.state = 367
                self.componentType()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 369
                self.match(PascalParser.ARRAY)
                self.state = 370
                self.match(PascalParser.LBRACK2)
                self.state = 371
                self.typeList()
                self.state = 372
                self.match(PascalParser.RBRACK2)
                self.state = 373
                self.match(PascalParser.OF)
                self.state = 374
                self.componentType()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def indexType(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PascalParser.IndexTypeContext)
            else:
                return self.getTypedRuleContext(PascalParser.IndexTypeContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(PascalParser.COMMA)
            else:
                return self.getToken(PascalParser.COMMA, i)

        def getRuleIndex(self):
            return PascalParser.RULE_typeList

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTypeList" ):
                return visitor.visitTypeList(self)
            else:
                return visitor.visitChildren(self)




    def typeList(self):

        localctx = PascalParser.TypeListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_typeList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 378
            self.indexType()
            self.state = 383
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==46:
                self.state = 379
                self.match(PascalParser.COMMA)
                self.state = 380
                self.indexType()
                self.state = 385
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IndexTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def simpleType(self):
            return self.getTypedRuleContext(PascalParser.SimpleTypeContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_indexType

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIndexType" ):
                return visitor.visitIndexType(self)
            else:
                return visitor.visitChildren(self)




    def indexType(self):

        localctx = PascalParser.IndexTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_indexType)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 386
            self.simpleType()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ComponentTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def type_(self):
            return self.getTypedRuleContext(PascalParser.Type_Context,0)


        def getRuleIndex(self):
            return PascalParser.RULE_componentType

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComponentType" ):
                return visitor.visitComponentType(self)
            else:
                return visitor.visitChildren(self)




    def componentType(self):

        localctx = PascalParser.ComponentTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_componentType)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 388
            self.type_()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RecordTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RECORD(self):
            return self.getToken(PascalParser.RECORD, 0)

        def END(self):
            return self.getToken(PascalParser.END, 0)

        def fieldList(self):
            return self.getTypedRuleContext(PascalParser.FieldListContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_recordType

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRecordType" ):
                return visitor.visitRecordType(self)
            else:
                return visitor.visitChildren(self)




    def recordType(self):

        localctx = PascalParser.RecordTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_recordType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 390
            self.match(PascalParser.RECORD)
            self.state = 392
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==5 or _la==77:
                self.state = 391
                self.fieldList()


            self.state = 394
            self.match(PascalParser.END)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FieldListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fixedPart(self):
            return self.getTypedRuleContext(PascalParser.FixedPartContext,0)


        def SEMI(self):
            return self.getToken(PascalParser.SEMI, 0)

        def variantPart(self):
            return self.getTypedRuleContext(PascalParser.VariantPartContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_fieldList

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFieldList" ):
                return visitor.visitFieldList(self)
            else:
                return visitor.visitChildren(self)




    def fieldList(self):

        localctx = PascalParser.FieldListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_fieldList)
        self._la = 0 # Token type
        try:
            self.state = 402
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [77]:
                self.enterOuterAlt(localctx, 1)
                self.state = 396
                self.fixedPart()
                self.state = 399
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==47:
                    self.state = 397
                    self.match(PascalParser.SEMI)
                    self.state = 398
                    self.variantPart()


                pass
            elif token in [5]:
                self.enterOuterAlt(localctx, 2)
                self.state = 401
                self.variantPart()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FixedPartContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def recordSection(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PascalParser.RecordSectionContext)
            else:
                return self.getTypedRuleContext(PascalParser.RecordSectionContext,i)


        def SEMI(self, i:int=None):
            if i is None:
                return self.getTokens(PascalParser.SEMI)
            else:
                return self.getToken(PascalParser.SEMI, i)

        def getRuleIndex(self):
            return PascalParser.RULE_fixedPart

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFixedPart" ):
                return visitor.visitFixedPart(self)
            else:
                return visitor.visitChildren(self)




    def fixedPart(self):

        localctx = PascalParser.FixedPartContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_fixedPart)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 404
            self.recordSection()
            self.state = 409
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,24,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 405
                    self.match(PascalParser.SEMI)
                    self.state = 406
                    self.recordSection() 
                self.state = 411
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,24,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RecordSectionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifierList(self):
            return self.getTypedRuleContext(PascalParser.IdentifierListContext,0)


        def COLON(self):
            return self.getToken(PascalParser.COLON, 0)

        def type_(self):
            return self.getTypedRuleContext(PascalParser.Type_Context,0)


        def getRuleIndex(self):
            return PascalParser.RULE_recordSection

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRecordSection" ):
                return visitor.visitRecordSection(self)
            else:
                return visitor.visitChildren(self)




    def recordSection(self):

        localctx = PascalParser.RecordSectionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_recordSection)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 412
            self.identifierList()
            self.state = 413
            self.match(PascalParser.COLON)
            self.state = 414
            self.type_()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VariantPartContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CASE(self):
            return self.getToken(PascalParser.CASE, 0)

        def tag(self):
            return self.getTypedRuleContext(PascalParser.TagContext,0)


        def OF(self):
            return self.getToken(PascalParser.OF, 0)

        def variant(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PascalParser.VariantContext)
            else:
                return self.getTypedRuleContext(PascalParser.VariantContext,i)


        def SEMI(self, i:int=None):
            if i is None:
                return self.getTokens(PascalParser.SEMI)
            else:
                return self.getToken(PascalParser.SEMI, i)

        def getRuleIndex(self):
            return PascalParser.RULE_variantPart

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVariantPart" ):
                return visitor.visitVariantPart(self)
            else:
                return visitor.visitChildren(self)




    def variantPart(self):

        localctx = PascalParser.VariantPartContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_variantPart)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 416
            self.match(PascalParser.CASE)
            self.state = 417
            self.tag()
            self.state = 418
            self.match(PascalParser.OF)
            self.state = 419
            self.variant()
            self.state = 424
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==47:
                self.state = 420
                self.match(PascalParser.SEMI)
                self.state = 421
                self.variant()
                self.state = 426
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TagContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(PascalParser.IdentifierContext,0)


        def COLON(self):
            return self.getToken(PascalParser.COLON, 0)

        def typeIdentifier(self):
            return self.getTypedRuleContext(PascalParser.TypeIdentifierContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_tag

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTag" ):
                return visitor.visitTag(self)
            else:
                return visitor.visitChildren(self)




    def tag(self):

        localctx = PascalParser.TagContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_tag)
        try:
            self.state = 432
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,26,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 427
                self.identifier()
                self.state = 428
                self.match(PascalParser.COLON)
                self.state = 429
                self.typeIdentifier()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 431
                self.typeIdentifier()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VariantContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def constList(self):
            return self.getTypedRuleContext(PascalParser.ConstListContext,0)


        def COLON(self):
            return self.getToken(PascalParser.COLON, 0)

        def LPAREN(self):
            return self.getToken(PascalParser.LPAREN, 0)

        def fieldList(self):
            return self.getTypedRuleContext(PascalParser.FieldListContext,0)


        def RPAREN(self):
            return self.getToken(PascalParser.RPAREN, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_variant

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVariant" ):
                return visitor.visitVariant(self)
            else:
                return visitor.visitChildren(self)




    def variant(self):

        localctx = PascalParser.VariantContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_variant)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 434
            self.constList()
            self.state = 435
            self.match(PascalParser.COLON)
            self.state = 436
            self.match(PascalParser.LPAREN)
            self.state = 437
            self.fieldList()
            self.state = 438
            self.match(PascalParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SetTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SET(self):
            return self.getToken(PascalParser.SET, 0)

        def OF(self):
            return self.getToken(PascalParser.OF, 0)

        def baseType(self):
            return self.getTypedRuleContext(PascalParser.BaseTypeContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_setType

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSetType" ):
                return visitor.visitSetType(self)
            else:
                return visitor.visitChildren(self)




    def setType(self):

        localctx = PascalParser.SetTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 80, self.RULE_setType)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 440
            self.match(PascalParser.SET)
            self.state = 441
            self.match(PascalParser.OF)
            self.state = 442
            self.baseType()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BaseTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def simpleType(self):
            return self.getTypedRuleContext(PascalParser.SimpleTypeContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_baseType

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBaseType" ):
                return visitor.visitBaseType(self)
            else:
                return visitor.visitChildren(self)




    def baseType(self):

        localctx = PascalParser.BaseTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 82, self.RULE_baseType)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 444
            self.simpleType()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FileTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FILE(self):
            return self.getToken(PascalParser.FILE, 0)

        def OF(self):
            return self.getToken(PascalParser.OF, 0)

        def type_(self):
            return self.getTypedRuleContext(PascalParser.Type_Context,0)


        def getRuleIndex(self):
            return PascalParser.RULE_fileType

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFileType" ):
                return visitor.visitFileType(self)
            else:
                return visitor.visitChildren(self)




    def fileType(self):

        localctx = PascalParser.FileTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 84, self.RULE_fileType)
        try:
            self.state = 450
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,27,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 446
                self.match(PascalParser.FILE)
                self.state = 447
                self.match(PascalParser.OF)
                self.state = 448
                self.type_()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 449
                self.match(PascalParser.FILE)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PointerTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def POINTER(self):
            return self.getToken(PascalParser.POINTER, 0)

        def typeIdentifier(self):
            return self.getTypedRuleContext(PascalParser.TypeIdentifierContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_pointerType

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPointerType" ):
                return visitor.visitPointerType(self)
            else:
                return visitor.visitChildren(self)




    def pointerType(self):

        localctx = PascalParser.PointerTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 86, self.RULE_pointerType)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 452
            self.match(PascalParser.POINTER)
            self.state = 453
            self.typeIdentifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VariableDeclarationPartContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def VAR(self):
            return self.getToken(PascalParser.VAR, 0)

        def variableDeclaration(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PascalParser.VariableDeclarationContext)
            else:
                return self.getTypedRuleContext(PascalParser.VariableDeclarationContext,i)


        def SEMI(self, i:int=None):
            if i is None:
                return self.getTokens(PascalParser.SEMI)
            else:
                return self.getToken(PascalParser.SEMI, i)

        def getRuleIndex(self):
            return PascalParser.RULE_variableDeclarationPart

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVariableDeclarationPart" ):
                return visitor.visitVariableDeclarationPart(self)
            else:
                return visitor.visitChildren(self)




    def variableDeclarationPart(self):

        localctx = PascalParser.VariableDeclarationPartContext(self, self._ctx, self.state)
        self.enterRule(localctx, 88, self.RULE_variableDeclarationPart)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 455
            self.match(PascalParser.VAR)
            self.state = 456
            self.variableDeclaration()
            self.state = 461
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,28,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 457
                    self.match(PascalParser.SEMI)
                    self.state = 458
                    self.variableDeclaration() 
                self.state = 463
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,28,self._ctx)

            self.state = 464
            self.match(PascalParser.SEMI)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VariableDeclarationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifierList(self):
            return self.getTypedRuleContext(PascalParser.IdentifierListContext,0)


        def COLON(self):
            return self.getToken(PascalParser.COLON, 0)

        def type_(self):
            return self.getTypedRuleContext(PascalParser.Type_Context,0)


        def getRuleIndex(self):
            return PascalParser.RULE_variableDeclaration

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVariableDeclaration" ):
                return visitor.visitVariableDeclaration(self)
            else:
                return visitor.visitChildren(self)




    def variableDeclaration(self):

        localctx = PascalParser.VariableDeclarationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 90, self.RULE_variableDeclaration)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 466
            self.identifierList()
            self.state = 467
            self.match(PascalParser.COLON)
            self.state = 468
            self.type_()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ProcedureAndFunctionDeclarationPartContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def procedureOrFunctionDeclaration(self):
            return self.getTypedRuleContext(PascalParser.ProcedureOrFunctionDeclarationContext,0)


        def SEMI(self):
            return self.getToken(PascalParser.SEMI, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_procedureAndFunctionDeclarationPart

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProcedureAndFunctionDeclarationPart" ):
                return visitor.visitProcedureAndFunctionDeclarationPart(self)
            else:
                return visitor.visitChildren(self)




    def procedureAndFunctionDeclarationPart(self):

        localctx = PascalParser.ProcedureAndFunctionDeclarationPartContext(self, self._ctx, self.state)
        self.enterRule(localctx, 92, self.RULE_procedureAndFunctionDeclarationPart)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 470
            self.procedureOrFunctionDeclaration()
            self.state = 471
            self.match(PascalParser.SEMI)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ProcedureOrFunctionDeclarationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def procedureDeclaration(self):
            return self.getTypedRuleContext(PascalParser.ProcedureDeclarationContext,0)


        def functionDeclaration(self):
            return self.getTypedRuleContext(PascalParser.FunctionDeclarationContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_procedureOrFunctionDeclaration

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProcedureOrFunctionDeclaration" ):
                return visitor.visitProcedureOrFunctionDeclaration(self)
            else:
                return visitor.visitChildren(self)




    def procedureOrFunctionDeclaration(self):

        localctx = PascalParser.ProcedureOrFunctionDeclarationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 94, self.RULE_procedureOrFunctionDeclaration)
        try:
            self.state = 475
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [28]:
                self.enterOuterAlt(localctx, 1)
                self.state = 473
                self.procedureDeclaration()
                pass
            elif token in [16]:
                self.enterOuterAlt(localctx, 2)
                self.state = 474
                self.functionDeclaration()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ProcedureDeclarationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PROCEDURE(self):
            return self.getToken(PascalParser.PROCEDURE, 0)

        def identifier(self):
            return self.getTypedRuleContext(PascalParser.IdentifierContext,0)


        def SEMI(self):
            return self.getToken(PascalParser.SEMI, 0)

        def block(self):
            return self.getTypedRuleContext(PascalParser.BlockContext,0)


        def formalParameterList(self):
            return self.getTypedRuleContext(PascalParser.FormalParameterListContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_procedureDeclaration

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProcedureDeclaration" ):
                return visitor.visitProcedureDeclaration(self)
            else:
                return visitor.visitChildren(self)




    def procedureDeclaration(self):

        localctx = PascalParser.ProcedureDeclarationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 96, self.RULE_procedureDeclaration)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 477
            self.match(PascalParser.PROCEDURE)
            self.state = 478
            self.identifier()
            self.state = 480
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==55:
                self.state = 479
                self.formalParameterList()


            self.state = 482
            self.match(PascalParser.SEMI)
            self.state = 483
            self.block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FormalParameterListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LPAREN(self):
            return self.getToken(PascalParser.LPAREN, 0)

        def formalParameterSection(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PascalParser.FormalParameterSectionContext)
            else:
                return self.getTypedRuleContext(PascalParser.FormalParameterSectionContext,i)


        def RPAREN(self):
            return self.getToken(PascalParser.RPAREN, 0)

        def SEMI(self, i:int=None):
            if i is None:
                return self.getTokens(PascalParser.SEMI)
            else:
                return self.getToken(PascalParser.SEMI, i)

        def getRuleIndex(self):
            return PascalParser.RULE_formalParameterList

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFormalParameterList" ):
                return visitor.visitFormalParameterList(self)
            else:
                return visitor.visitChildren(self)




    def formalParameterList(self):

        localctx = PascalParser.FormalParameterListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 98, self.RULE_formalParameterList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 485
            self.match(PascalParser.LPAREN)
            self.state = 486
            self.formalParameterSection()
            self.state = 491
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==47:
                self.state = 487
                self.match(PascalParser.SEMI)
                self.state = 488
                self.formalParameterSection()
                self.state = 493
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 494
            self.match(PascalParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FormalParameterSectionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def parameterGroup(self):
            return self.getTypedRuleContext(PascalParser.ParameterGroupContext,0)


        def VAR(self):
            return self.getToken(PascalParser.VAR, 0)

        def FUNCTION(self):
            return self.getToken(PascalParser.FUNCTION, 0)

        def PROCEDURE(self):
            return self.getToken(PascalParser.PROCEDURE, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_formalParameterSection

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFormalParameterSection" ):
                return visitor.visitFormalParameterSection(self)
            else:
                return visitor.visitChildren(self)




    def formalParameterSection(self):

        localctx = PascalParser.FormalParameterSectionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 100, self.RULE_formalParameterSection)
        try:
            self.state = 503
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [77]:
                self.enterOuterAlt(localctx, 1)
                self.state = 496
                self.parameterGroup()
                pass
            elif token in [38]:
                self.enterOuterAlt(localctx, 2)
                self.state = 497
                self.match(PascalParser.VAR)
                self.state = 498
                self.parameterGroup()
                pass
            elif token in [16]:
                self.enterOuterAlt(localctx, 3)
                self.state = 499
                self.match(PascalParser.FUNCTION)
                self.state = 500
                self.parameterGroup()
                pass
            elif token in [28]:
                self.enterOuterAlt(localctx, 4)
                self.state = 501
                self.match(PascalParser.PROCEDURE)
                self.state = 502
                self.parameterGroup()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParameterGroupContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifierList(self):
            return self.getTypedRuleContext(PascalParser.IdentifierListContext,0)


        def COLON(self):
            return self.getToken(PascalParser.COLON, 0)

        def typeIdentifier(self):
            return self.getTypedRuleContext(PascalParser.TypeIdentifierContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_parameterGroup

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParameterGroup" ):
                return visitor.visitParameterGroup(self)
            else:
                return visitor.visitChildren(self)




    def parameterGroup(self):

        localctx = PascalParser.ParameterGroupContext(self, self._ctx, self.state)
        self.enterRule(localctx, 102, self.RULE_parameterGroup)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 505
            self.identifierList()
            self.state = 506
            self.match(PascalParser.COLON)
            self.state = 507
            self.typeIdentifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IdentifierListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PascalParser.IdentifierContext)
            else:
                return self.getTypedRuleContext(PascalParser.IdentifierContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(PascalParser.COMMA)
            else:
                return self.getToken(PascalParser.COMMA, i)

        def getRuleIndex(self):
            return PascalParser.RULE_identifierList

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIdentifierList" ):
                return visitor.visitIdentifierList(self)
            else:
                return visitor.visitChildren(self)




    def identifierList(self):

        localctx = PascalParser.IdentifierListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 104, self.RULE_identifierList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 509
            self.identifier()
            self.state = 514
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==46:
                self.state = 510
                self.match(PascalParser.COMMA)
                self.state = 511
                self.identifier()
                self.state = 516
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def constant(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PascalParser.ConstantContext)
            else:
                return self.getTypedRuleContext(PascalParser.ConstantContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(PascalParser.COMMA)
            else:
                return self.getToken(PascalParser.COMMA, i)

        def getRuleIndex(self):
            return PascalParser.RULE_constList

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitConstList" ):
                return visitor.visitConstList(self)
            else:
                return visitor.visitChildren(self)




    def constList(self):

        localctx = PascalParser.ConstListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 106, self.RULE_constList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 517
            self.constant()
            self.state = 522
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==46:
                self.state = 518
                self.match(PascalParser.COMMA)
                self.state = 519
                self.constant()
                self.state = 524
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionDeclarationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FUNCTION(self):
            return self.getToken(PascalParser.FUNCTION, 0)

        def identifier(self):
            return self.getTypedRuleContext(PascalParser.IdentifierContext,0)


        def COLON(self):
            return self.getToken(PascalParser.COLON, 0)

        def resultType(self):
            return self.getTypedRuleContext(PascalParser.ResultTypeContext,0)


        def SEMI(self):
            return self.getToken(PascalParser.SEMI, 0)

        def block(self):
            return self.getTypedRuleContext(PascalParser.BlockContext,0)


        def formalParameterList(self):
            return self.getTypedRuleContext(PascalParser.FormalParameterListContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_functionDeclaration

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFunctionDeclaration" ):
                return visitor.visitFunctionDeclaration(self)
            else:
                return visitor.visitChildren(self)




    def functionDeclaration(self):

        localctx = PascalParser.FunctionDeclarationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 108, self.RULE_functionDeclaration)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 525
            self.match(PascalParser.FUNCTION)
            self.state = 526
            self.identifier()
            self.state = 528
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==55:
                self.state = 527
                self.formalParameterList()


            self.state = 530
            self.match(PascalParser.COLON)
            self.state = 531
            self.resultType()
            self.state = 532
            self.match(PascalParser.SEMI)
            self.state = 533
            self.block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ResultTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def typeIdentifier(self):
            return self.getTypedRuleContext(PascalParser.TypeIdentifierContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_resultType

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitResultType" ):
                return visitor.visitResultType(self)
            else:
                return visitor.visitChildren(self)




    def resultType(self):

        localctx = PascalParser.ResultTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 110, self.RULE_resultType)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 535
            self.typeIdentifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def label(self):
            return self.getTypedRuleContext(PascalParser.LabelContext,0)


        def COLON(self):
            return self.getToken(PascalParser.COLON, 0)

        def unlabelledStatement(self):
            return self.getTypedRuleContext(PascalParser.UnlabelledStatementContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_statement

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStatement" ):
                return visitor.visitStatement(self)
            else:
                return visitor.visitChildren(self)




    def statement(self):

        localctx = PascalParser.StatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 112, self.RULE_statement)
        try:
            self.state = 542
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [79]:
                self.enterOuterAlt(localctx, 1)
                self.state = 537
                self.label()
                self.state = 538
                self.match(PascalParser.COLON)
                self.state = 539
                self.unlabelledStatement()
                pass
            elif token in [3, 5, 12, 13, 15, 17, 18, 32, 37, 39, 40, 47, 62, 77]:
                self.enterOuterAlt(localctx, 2)
                self.state = 541
                self.unlabelledStatement()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UnlabelledStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def simpleStatement(self):
            return self.getTypedRuleContext(PascalParser.SimpleStatementContext,0)


        def structuredStatement(self):
            return self.getTypedRuleContext(PascalParser.StructuredStatementContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_unlabelledStatement

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnlabelledStatement" ):
                return visitor.visitUnlabelledStatement(self)
            else:
                return visitor.visitChildren(self)




    def unlabelledStatement(self):

        localctx = PascalParser.UnlabelledStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 114, self.RULE_unlabelledStatement)
        try:
            self.state = 546
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [12, 13, 17, 37, 47, 62, 77]:
                self.enterOuterAlt(localctx, 1)
                self.state = 544
                self.simpleStatement()
                pass
            elif token in [3, 5, 15, 18, 32, 39, 40]:
                self.enterOuterAlt(localctx, 2)
                self.state = 545
                self.structuredStatement()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SimpleStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def assignmentStatement(self):
            return self.getTypedRuleContext(PascalParser.AssignmentStatementContext,0)


        def procedureStatement(self):
            return self.getTypedRuleContext(PascalParser.ProcedureStatementContext,0)


        def gotoStatement(self):
            return self.getTypedRuleContext(PascalParser.GotoStatementContext,0)


        def emptyStatement_(self):
            return self.getTypedRuleContext(PascalParser.EmptyStatement_Context,0)


        def getRuleIndex(self):
            return PascalParser.RULE_simpleStatement

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSimpleStatement" ):
                return visitor.visitSimpleStatement(self)
            else:
                return visitor.visitChildren(self)




    def simpleStatement(self):

        localctx = PascalParser.SimpleStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 116, self.RULE_simpleStatement)
        try:
            self.state = 552
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,38,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 548
                self.assignmentStatement()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 549
                self.procedureStatement()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 550
                self.gotoStatement()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 551
                self.emptyStatement_()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AssignmentStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def variable(self):
            return self.getTypedRuleContext(PascalParser.VariableContext,0)


        def ASSIGN(self):
            return self.getToken(PascalParser.ASSIGN, 0)

        def expression(self):
            return self.getTypedRuleContext(PascalParser.ExpressionContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_assignmentStatement

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAssignmentStatement" ):
                return visitor.visitAssignmentStatement(self)
            else:
                return visitor.visitChildren(self)




    def assignmentStatement(self):

        localctx = PascalParser.AssignmentStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 118, self.RULE_assignmentStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 554
            self.variable()
            self.state = 555
            self.match(PascalParser.ASSIGN)
            self.state = 556
            self.expression()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VariableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def AT(self):
            return self.getToken(PascalParser.AT, 0)

        def identifier(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PascalParser.IdentifierContext)
            else:
                return self.getTypedRuleContext(PascalParser.IdentifierContext,i)


        def LBRACK(self, i:int=None):
            if i is None:
                return self.getTokens(PascalParser.LBRACK)
            else:
                return self.getToken(PascalParser.LBRACK, i)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PascalParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(PascalParser.ExpressionContext,i)


        def RBRACK(self, i:int=None):
            if i is None:
                return self.getTokens(PascalParser.RBRACK)
            else:
                return self.getToken(PascalParser.RBRACK, i)

        def LBRACK2(self, i:int=None):
            if i is None:
                return self.getTokens(PascalParser.LBRACK2)
            else:
                return self.getToken(PascalParser.LBRACK2, i)

        def RBRACK2(self, i:int=None):
            if i is None:
                return self.getTokens(PascalParser.RBRACK2)
            else:
                return self.getToken(PascalParser.RBRACK2, i)

        def DOT(self, i:int=None):
            if i is None:
                return self.getTokens(PascalParser.DOT)
            else:
                return self.getToken(PascalParser.DOT, i)

        def POINTER(self, i:int=None):
            if i is None:
                return self.getTokens(PascalParser.POINTER)
            else:
                return self.getToken(PascalParser.POINTER, i)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(PascalParser.COMMA)
            else:
                return self.getToken(PascalParser.COMMA, i)

        def getRuleIndex(self):
            return PascalParser.RULE_variable

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVariable" ):
                return visitor.visitVariable(self)
            else:
                return visitor.visitChildren(self)




    def variable(self):

        localctx = PascalParser.VariableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 120, self.RULE_variable)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 561
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [62]:
                self.state = 558
                self.match(PascalParser.AT)
                self.state = 559
                self.identifier()
                pass
            elif token in [77]:
                self.state = 560
                self.identifier()
                pass
            else:
                raise NoViableAltException(self)

            self.state = 590
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & -6485183463413514240) != 0):
                self.state = 588
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [57]:
                    self.state = 563
                    self.match(PascalParser.LBRACK)
                    self.state = 564
                    self.expression()
                    self.state = 569
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while _la==46:
                        self.state = 565
                        self.match(PascalParser.COMMA)
                        self.state = 566
                        self.expression()
                        self.state = 571
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)

                    self.state = 572
                    self.match(PascalParser.RBRACK)
                    pass
                elif token in [58]:
                    self.state = 574
                    self.match(PascalParser.LBRACK2)
                    self.state = 575
                    self.expression()
                    self.state = 580
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while _la==46:
                        self.state = 576
                        self.match(PascalParser.COMMA)
                        self.state = 577
                        self.expression()
                        self.state = 582
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)

                    self.state = 583
                    self.match(PascalParser.RBRACK2)
                    pass
                elif token in [63]:
                    self.state = 585
                    self.match(PascalParser.DOT)
                    self.state = 586
                    self.identifier()
                    pass
                elif token in [61]:
                    self.state = 587
                    self.match(PascalParser.POINTER)
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 592
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def simpleExpression(self):
            return self.getTypedRuleContext(PascalParser.SimpleExpressionContext,0)


        def relationaloperator(self):
            return self.getTypedRuleContext(PascalParser.RelationaloperatorContext,0)


        def expression(self):
            return self.getTypedRuleContext(PascalParser.ExpressionContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_expression

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpression" ):
                return visitor.visitExpression(self)
            else:
                return visitor.visitChildren(self)




    def expression(self):

        localctx = PascalParser.ExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 122, self.RULE_expression)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 593
            self.simpleExpression()
            self.state = 597
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 35465847066066944) != 0):
                self.state = 594
                self.relationaloperator()
                self.state = 595
                self.expression()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RelationaloperatorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EQUAL(self):
            return self.getToken(PascalParser.EQUAL, 0)

        def NOT_EQUAL(self):
            return self.getToken(PascalParser.NOT_EQUAL, 0)

        def LT(self):
            return self.getToken(PascalParser.LT, 0)

        def LE(self):
            return self.getToken(PascalParser.LE, 0)

        def GE(self):
            return self.getToken(PascalParser.GE, 0)

        def GT(self):
            return self.getToken(PascalParser.GT, 0)

        def IN(self):
            return self.getToken(PascalParser.IN, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_relationaloperator

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRelationaloperator" ):
                return visitor.visitRelationaloperator(self)
            else:
                return visitor.visitChildren(self)




    def relationaloperator(self):

        localctx = PascalParser.RelationaloperatorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 124, self.RULE_relationaloperator)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 599
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 35465847066066944) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SimpleExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def term(self):
            return self.getTypedRuleContext(PascalParser.TermContext,0)


        def additiveoperator(self):
            return self.getTypedRuleContext(PascalParser.AdditiveoperatorContext,0)


        def simpleExpression(self):
            return self.getTypedRuleContext(PascalParser.SimpleExpressionContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_simpleExpression

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSimpleExpression" ):
                return visitor.visitSimpleExpression(self)
            else:
                return visitor.visitChildren(self)




    def simpleExpression(self):

        localctx = PascalParser.SimpleExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 126, self.RULE_simpleExpression)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 601
            self.term()
            self.state = 605
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 6597136875520) != 0):
                self.state = 602
                self.additiveoperator()
                self.state = 603
                self.simpleExpression()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AdditiveoperatorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PLUS(self):
            return self.getToken(PascalParser.PLUS, 0)

        def MINUS(self):
            return self.getToken(PascalParser.MINUS, 0)

        def OR(self):
            return self.getToken(PascalParser.OR, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_additiveoperator

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAdditiveoperator" ):
                return visitor.visitAdditiveoperator(self)
            else:
                return visitor.visitChildren(self)




    def additiveoperator(self):

        localctx = PascalParser.AdditiveoperatorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 128, self.RULE_additiveoperator)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 607
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 6597136875520) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TermContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def signedFactor(self):
            return self.getTypedRuleContext(PascalParser.SignedFactorContext,0)


        def multiplicativeoperator(self):
            return self.getTypedRuleContext(PascalParser.MultiplicativeoperatorContext,0)


        def term(self):
            return self.getTypedRuleContext(PascalParser.TermContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_term

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTerm" ):
                return visitor.visitTerm(self)
            else:
                return visitor.visitChildren(self)




    def term(self):

        localctx = PascalParser.TermContext(self, self._ctx, self.state)
        self.enterRule(localctx, 130, self.RULE_term)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 609
            self.signedFactor()
            self.state = 613
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 26388283261442) != 0):
                self.state = 610
                self.multiplicativeoperator()
                self.state = 611
                self.term()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MultiplicativeoperatorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def STAR(self):
            return self.getToken(PascalParser.STAR, 0)

        def SLASH(self):
            return self.getToken(PascalParser.SLASH, 0)

        def DIV(self):
            return self.getToken(PascalParser.DIV, 0)

        def MOD(self):
            return self.getToken(PascalParser.MOD, 0)

        def AND(self):
            return self.getToken(PascalParser.AND, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_multiplicativeoperator

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMultiplicativeoperator" ):
                return visitor.visitMultiplicativeoperator(self)
            else:
                return visitor.visitChildren(self)




    def multiplicativeoperator(self):

        localctx = PascalParser.MultiplicativeoperatorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 132, self.RULE_multiplicativeoperator)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 615
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 26388283261442) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SignedFactorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def factor(self):
            return self.getTypedRuleContext(PascalParser.FactorContext,0)


        def PLUS(self):
            return self.getToken(PascalParser.PLUS, 0)

        def MINUS(self):
            return self.getToken(PascalParser.MINUS, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_signedFactor

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSignedFactor" ):
                return visitor.visitSignedFactor(self)
            else:
                return visitor.visitChildren(self)




    def signedFactor(self):

        localctx = PascalParser.SignedFactorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 134, self.RULE_signedFactor)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 618
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==41 or _la==42:
                self.state = 617
                _la = self._input.LA(1)
                if not(_la==41 or _la==42):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()


            self.state = 620
            self.factor()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FactorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def variable(self):
            return self.getTypedRuleContext(PascalParser.VariableContext,0)


        def LPAREN(self):
            return self.getToken(PascalParser.LPAREN, 0)

        def expression(self):
            return self.getTypedRuleContext(PascalParser.ExpressionContext,0)


        def RPAREN(self):
            return self.getToken(PascalParser.RPAREN, 0)

        def functionDesignator(self):
            return self.getTypedRuleContext(PascalParser.FunctionDesignatorContext,0)


        def unsignedConstant(self):
            return self.getTypedRuleContext(PascalParser.UnsignedConstantContext,0)


        def set_(self):
            return self.getTypedRuleContext(PascalParser.Set_Context,0)


        def NOT(self):
            return self.getToken(PascalParser.NOT, 0)

        def factor(self):
            return self.getTypedRuleContext(PascalParser.FactorContext,0)


        def bool_(self):
            return self.getTypedRuleContext(PascalParser.Bool_Context,0)


        def getRuleIndex(self):
            return PascalParser.RULE_factor

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFactor" ):
                return visitor.visitFactor(self)
            else:
                return visitor.visitChildren(self)




    def factor(self):

        localctx = PascalParser.FactorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 136, self.RULE_factor)
        try:
            self.state = 633
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,48,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 622
                self.variable()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 623
                self.match(PascalParser.LPAREN)
                self.state = 624
                self.expression()
                self.state = 625
                self.match(PascalParser.RPAREN)
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 627
                self.functionDesignator()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 628
                self.unsignedConstant()
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 629
                self.set_()
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 630
                self.match(PascalParser.NOT)
                self.state = 631
                self.factor()
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 632
                self.bool_()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UnsignedConstantContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def unsignedNumber(self):
            return self.getTypedRuleContext(PascalParser.UnsignedNumberContext,0)


        def constantChr(self):
            return self.getTypedRuleContext(PascalParser.ConstantChrContext,0)


        def string(self):
            return self.getTypedRuleContext(PascalParser.StringContext,0)


        def NIL(self):
            return self.getToken(PascalParser.NIL, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_unsignedConstant

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnsignedConstant" ):
                return visitor.visitUnsignedConstant(self)
            else:
                return visitor.visitChildren(self)




    def unsignedConstant(self):

        localctx = PascalParser.UnsignedConstantContext(self, self._ctx, self.state)
        self.enterRule(localctx, 138, self.RULE_unsignedConstant)
        try:
            self.state = 639
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [79, 80]:
                self.enterOuterAlt(localctx, 1)
                self.state = 635
                self.unsignedNumber()
                pass
            elif token in [7]:
                self.enterOuterAlt(localctx, 2)
                self.state = 636
                self.constantChr()
                pass
            elif token in [78]:
                self.enterOuterAlt(localctx, 3)
                self.state = 637
                self.string()
                pass
            elif token in [23]:
                self.enterOuterAlt(localctx, 4)
                self.state = 638
                self.match(PascalParser.NIL)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionDesignatorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(PascalParser.IdentifierContext,0)


        def LPAREN(self):
            return self.getToken(PascalParser.LPAREN, 0)

        def parameterList(self):
            return self.getTypedRuleContext(PascalParser.ParameterListContext,0)


        def RPAREN(self):
            return self.getToken(PascalParser.RPAREN, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_functionDesignator

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFunctionDesignator" ):
                return visitor.visitFunctionDesignator(self)
            else:
                return visitor.visitChildren(self)




    def functionDesignator(self):

        localctx = PascalParser.FunctionDesignatorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 140, self.RULE_functionDesignator)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 641
            self.identifier()
            self.state = 642
            self.match(PascalParser.LPAREN)
            self.state = 643
            self.parameterList()
            self.state = 644
            self.match(PascalParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParameterListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def actualParameter(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PascalParser.ActualParameterContext)
            else:
                return self.getTypedRuleContext(PascalParser.ActualParameterContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(PascalParser.COMMA)
            else:
                return self.getToken(PascalParser.COMMA, i)

        def getRuleIndex(self):
            return PascalParser.RULE_parameterList

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParameterList" ):
                return visitor.visitParameterList(self)
            else:
                return visitor.visitChildren(self)




    def parameterList(self):

        localctx = PascalParser.ParameterListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 142, self.RULE_parameterList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 646
            self.actualParameter()
            self.state = 651
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==46:
                self.state = 647
                self.match(PascalParser.COMMA)
                self.state = 648
                self.actualParameter()
                self.state = 653
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Set_Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LBRACK(self):
            return self.getToken(PascalParser.LBRACK, 0)

        def elementList(self):
            return self.getTypedRuleContext(PascalParser.ElementListContext,0)


        def RBRACK(self):
            return self.getToken(PascalParser.RBRACK, 0)

        def LBRACK2(self):
            return self.getToken(PascalParser.LBRACK2, 0)

        def RBRACK2(self):
            return self.getToken(PascalParser.RBRACK2, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_set_

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSet_" ):
                return visitor.visitSet_(self)
            else:
                return visitor.visitChildren(self)




    def set_(self):

        localctx = PascalParser.Set_Context(self, self._ctx, self.state)
        self.enterRule(localctx, 144, self.RULE_set_)
        try:
            self.state = 662
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [57]:
                self.enterOuterAlt(localctx, 1)
                self.state = 654
                self.match(PascalParser.LBRACK)
                self.state = 655
                self.elementList()
                self.state = 656
                self.match(PascalParser.RBRACK)
                pass
            elif token in [58]:
                self.enterOuterAlt(localctx, 2)
                self.state = 658
                self.match(PascalParser.LBRACK2)
                self.state = 659
                self.elementList()
                self.state = 660
                self.match(PascalParser.RBRACK2)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ElementListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def element(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PascalParser.ElementContext)
            else:
                return self.getTypedRuleContext(PascalParser.ElementContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(PascalParser.COMMA)
            else:
                return self.getToken(PascalParser.COMMA, i)

        def getRuleIndex(self):
            return PascalParser.RULE_elementList

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitElementList" ):
                return visitor.visitElementList(self)
            else:
                return visitor.visitChildren(self)




    def elementList(self):

        localctx = PascalParser.ElementListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 146, self.RULE_elementList)
        self._la = 0 # Token type
        try:
            self.state = 673
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [7, 23, 24, 41, 42, 55, 57, 58, 62, 72, 73, 77, 78, 79, 80]:
                self.enterOuterAlt(localctx, 1)
                self.state = 664
                self.element()
                self.state = 669
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==46:
                    self.state = 665
                    self.match(PascalParser.COMMA)
                    self.state = 666
                    self.element()
                    self.state = 671
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                pass
            elif token in [59, 60]:
                self.enterOuterAlt(localctx, 2)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ElementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PascalParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(PascalParser.ExpressionContext,i)


        def DOTDOT(self):
            return self.getToken(PascalParser.DOTDOT, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_element

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitElement" ):
                return visitor.visitElement(self)
            else:
                return visitor.visitChildren(self)




    def element(self):

        localctx = PascalParser.ElementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 148, self.RULE_element)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 675
            self.expression()
            self.state = 678
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==64:
                self.state = 676
                self.match(PascalParser.DOTDOT)
                self.state = 677
                self.expression()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ProcedureStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(PascalParser.IdentifierContext,0)


        def LPAREN(self):
            return self.getToken(PascalParser.LPAREN, 0)

        def parameterList(self):
            return self.getTypedRuleContext(PascalParser.ParameterListContext,0)


        def RPAREN(self):
            return self.getToken(PascalParser.RPAREN, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_procedureStatement

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProcedureStatement" ):
                return visitor.visitProcedureStatement(self)
            else:
                return visitor.visitChildren(self)




    def procedureStatement(self):

        localctx = PascalParser.ProcedureStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 150, self.RULE_procedureStatement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 680
            self.identifier()
            self.state = 685
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==55:
                self.state = 681
                self.match(PascalParser.LPAREN)
                self.state = 682
                self.parameterList()
                self.state = 683
                self.match(PascalParser.RPAREN)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ActualParameterContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self):
            return self.getTypedRuleContext(PascalParser.ExpressionContext,0)


        def parameterwidth(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PascalParser.ParameterwidthContext)
            else:
                return self.getTypedRuleContext(PascalParser.ParameterwidthContext,i)


        def getRuleIndex(self):
            return PascalParser.RULE_actualParameter

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitActualParameter" ):
                return visitor.visitActualParameter(self)
            else:
                return visitor.visitChildren(self)




    def actualParameter(self):

        localctx = PascalParser.ActualParameterContext(self, self._ctx, self.state)
        self.enterRule(localctx, 152, self.RULE_actualParameter)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 687
            self.expression()
            self.state = 691
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==48:
                self.state = 688
                self.parameterwidth()
                self.state = 693
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParameterwidthContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def COLON(self):
            return self.getToken(PascalParser.COLON, 0)

        def expression(self):
            return self.getTypedRuleContext(PascalParser.ExpressionContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_parameterwidth

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParameterwidth" ):
                return visitor.visitParameterwidth(self)
            else:
                return visitor.visitChildren(self)




    def parameterwidth(self):

        localctx = PascalParser.ParameterwidthContext(self, self._ctx, self.state)
        self.enterRule(localctx, 154, self.RULE_parameterwidth)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 694
            self.match(PascalParser.COLON)
            self.state = 695
            self.expression()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class GotoStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def GOTO(self):
            return self.getToken(PascalParser.GOTO, 0)

        def label(self):
            return self.getTypedRuleContext(PascalParser.LabelContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_gotoStatement

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitGotoStatement" ):
                return visitor.visitGotoStatement(self)
            else:
                return visitor.visitChildren(self)




    def gotoStatement(self):

        localctx = PascalParser.GotoStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 156, self.RULE_gotoStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 697
            self.match(PascalParser.GOTO)
            self.state = 698
            self.label()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EmptyStatement_Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return PascalParser.RULE_emptyStatement_

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEmptyStatement_" ):
                return visitor.visitEmptyStatement_(self)
            else:
                return visitor.visitChildren(self)




    def emptyStatement_(self):

        localctx = PascalParser.EmptyStatement_Context(self, self._ctx, self.state)
        self.enterRule(localctx, 158, self.RULE_emptyStatement_)
        try:
            self.enterOuterAlt(localctx, 1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Empty_Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return PascalParser.RULE_empty_

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEmpty_" ):
                return visitor.visitEmpty_(self)
            else:
                return visitor.visitChildren(self)




    def empty_(self):

        localctx = PascalParser.Empty_Context(self, self._ctx, self.state)
        self.enterRule(localctx, 160, self.RULE_empty_)
        try:
            self.enterOuterAlt(localctx, 1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StructuredStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def compoundStatement(self):
            return self.getTypedRuleContext(PascalParser.CompoundStatementContext,0)


        def conditionalStatement(self):
            return self.getTypedRuleContext(PascalParser.ConditionalStatementContext,0)


        def repetetiveStatement(self):
            return self.getTypedRuleContext(PascalParser.RepetetiveStatementContext,0)


        def withStatement(self):
            return self.getTypedRuleContext(PascalParser.WithStatementContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_structuredStatement

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStructuredStatement" ):
                return visitor.visitStructuredStatement(self)
            else:
                return visitor.visitChildren(self)




    def structuredStatement(self):

        localctx = PascalParser.StructuredStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 162, self.RULE_structuredStatement)
        try:
            self.state = 708
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [3]:
                self.enterOuterAlt(localctx, 1)
                self.state = 704
                self.compoundStatement()
                pass
            elif token in [5, 18]:
                self.enterOuterAlt(localctx, 2)
                self.state = 705
                self.conditionalStatement()
                pass
            elif token in [15, 32, 39]:
                self.enterOuterAlt(localctx, 3)
                self.state = 706
                self.repetetiveStatement()
                pass
            elif token in [40]:
                self.enterOuterAlt(localctx, 4)
                self.state = 707
                self.withStatement()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CompoundStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BEGIN(self):
            return self.getToken(PascalParser.BEGIN, 0)

        def statements(self):
            return self.getTypedRuleContext(PascalParser.StatementsContext,0)


        def END(self):
            return self.getToken(PascalParser.END, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_compoundStatement

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCompoundStatement" ):
                return visitor.visitCompoundStatement(self)
            else:
                return visitor.visitChildren(self)




    def compoundStatement(self):

        localctx = PascalParser.CompoundStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 164, self.RULE_compoundStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 710
            self.match(PascalParser.BEGIN)
            self.state = 711
            self.statements()
            self.state = 712
            self.match(PascalParser.END)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatementsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PascalParser.StatementContext)
            else:
                return self.getTypedRuleContext(PascalParser.StatementContext,i)


        def SEMI(self, i:int=None):
            if i is None:
                return self.getTokens(PascalParser.SEMI)
            else:
                return self.getToken(PascalParser.SEMI, i)

        def getRuleIndex(self):
            return PascalParser.RULE_statements

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStatements" ):
                return visitor.visitStatements(self)
            else:
                return visitor.visitChildren(self)




    def statements(self):

        localctx = PascalParser.StatementsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 166, self.RULE_statements)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 714
            self.statement()
            self.state = 719
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==47:
                self.state = 715
                self.match(PascalParser.SEMI)
                self.state = 716
                self.statement()
                self.state = 721
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConditionalStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ifStatement(self):
            return self.getTypedRuleContext(PascalParser.IfStatementContext,0)


        def caseStatement(self):
            return self.getTypedRuleContext(PascalParser.CaseStatementContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_conditionalStatement

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitConditionalStatement" ):
                return visitor.visitConditionalStatement(self)
            else:
                return visitor.visitChildren(self)




    def conditionalStatement(self):

        localctx = PascalParser.ConditionalStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 168, self.RULE_conditionalStatement)
        try:
            self.state = 724
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [18]:
                self.enterOuterAlt(localctx, 1)
                self.state = 722
                self.ifStatement()
                pass
            elif token in [5]:
                self.enterOuterAlt(localctx, 2)
                self.state = 723
                self.caseStatement()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IfStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IF(self):
            return self.getToken(PascalParser.IF, 0)

        def expression(self):
            return self.getTypedRuleContext(PascalParser.ExpressionContext,0)


        def THEN(self):
            return self.getToken(PascalParser.THEN, 0)

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PascalParser.StatementContext)
            else:
                return self.getTypedRuleContext(PascalParser.StatementContext,i)


        def ELSE(self):
            return self.getToken(PascalParser.ELSE, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_ifStatement

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIfStatement" ):
                return visitor.visitIfStatement(self)
            else:
                return visitor.visitChildren(self)




    def ifStatement(self):

        localctx = PascalParser.IfStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 170, self.RULE_ifStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 726
            self.match(PascalParser.IF)
            self.state = 727
            self.expression()
            self.state = 728
            self.match(PascalParser.THEN)
            self.state = 729
            self.statement()
            self.state = 732
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,60,self._ctx)
            if la_ == 1:
                self.state = 730
                self.match(PascalParser.ELSE)
                self.state = 731
                self.statement()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CaseStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CASE(self):
            return self.getToken(PascalParser.CASE, 0)

        def expression(self):
            return self.getTypedRuleContext(PascalParser.ExpressionContext,0)


        def OF(self):
            return self.getToken(PascalParser.OF, 0)

        def caseListElement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PascalParser.CaseListElementContext)
            else:
                return self.getTypedRuleContext(PascalParser.CaseListElementContext,i)


        def END(self):
            return self.getToken(PascalParser.END, 0)

        def SEMI(self, i:int=None):
            if i is None:
                return self.getTokens(PascalParser.SEMI)
            else:
                return self.getToken(PascalParser.SEMI, i)

        def ELSE(self):
            return self.getToken(PascalParser.ELSE, 0)

        def statements(self):
            return self.getTypedRuleContext(PascalParser.StatementsContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_caseStatement

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCaseStatement" ):
                return visitor.visitCaseStatement(self)
            else:
                return visitor.visitChildren(self)




    def caseStatement(self):

        localctx = PascalParser.CaseStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 172, self.RULE_caseStatement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 734
            self.match(PascalParser.CASE)
            self.state = 735
            self.expression()
            self.state = 736
            self.match(PascalParser.OF)
            self.state = 737
            self.caseListElement()
            self.state = 742
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,61,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 738
                    self.match(PascalParser.SEMI)
                    self.state = 739
                    self.caseListElement() 
                self.state = 744
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,61,self._ctx)

            self.state = 748
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==47:
                self.state = 745
                self.match(PascalParser.SEMI)
                self.state = 746
                self.match(PascalParser.ELSE)
                self.state = 747
                self.statements()


            self.state = 750
            self.match(PascalParser.END)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CaseListElementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def constList(self):
            return self.getTypedRuleContext(PascalParser.ConstListContext,0)


        def COLON(self):
            return self.getToken(PascalParser.COLON, 0)

        def statement(self):
            return self.getTypedRuleContext(PascalParser.StatementContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_caseListElement

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCaseListElement" ):
                return visitor.visitCaseListElement(self)
            else:
                return visitor.visitChildren(self)




    def caseListElement(self):

        localctx = PascalParser.CaseListElementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 174, self.RULE_caseListElement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 752
            self.constList()
            self.state = 753
            self.match(PascalParser.COLON)
            self.state = 754
            self.statement()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RepetetiveStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def whileStatement(self):
            return self.getTypedRuleContext(PascalParser.WhileStatementContext,0)


        def repeatStatement(self):
            return self.getTypedRuleContext(PascalParser.RepeatStatementContext,0)


        def forStatement(self):
            return self.getTypedRuleContext(PascalParser.ForStatementContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_repetetiveStatement

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRepetetiveStatement" ):
                return visitor.visitRepetetiveStatement(self)
            else:
                return visitor.visitChildren(self)




    def repetetiveStatement(self):

        localctx = PascalParser.RepetetiveStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 176, self.RULE_repetetiveStatement)
        try:
            self.state = 759
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [39]:
                self.enterOuterAlt(localctx, 1)
                self.state = 756
                self.whileStatement()
                pass
            elif token in [32]:
                self.enterOuterAlt(localctx, 2)
                self.state = 757
                self.repeatStatement()
                pass
            elif token in [15]:
                self.enterOuterAlt(localctx, 3)
                self.state = 758
                self.forStatement()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class WhileStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WHILE(self):
            return self.getToken(PascalParser.WHILE, 0)

        def expression(self):
            return self.getTypedRuleContext(PascalParser.ExpressionContext,0)


        def DO(self):
            return self.getToken(PascalParser.DO, 0)

        def statement(self):
            return self.getTypedRuleContext(PascalParser.StatementContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_whileStatement

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitWhileStatement" ):
                return visitor.visitWhileStatement(self)
            else:
                return visitor.visitChildren(self)




    def whileStatement(self):

        localctx = PascalParser.WhileStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 178, self.RULE_whileStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 761
            self.match(PascalParser.WHILE)
            self.state = 762
            self.expression()
            self.state = 763
            self.match(PascalParser.DO)
            self.state = 764
            self.statement()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RepeatStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def REPEAT(self):
            return self.getToken(PascalParser.REPEAT, 0)

        def statements(self):
            return self.getTypedRuleContext(PascalParser.StatementsContext,0)


        def UNTIL(self):
            return self.getToken(PascalParser.UNTIL, 0)

        def expression(self):
            return self.getTypedRuleContext(PascalParser.ExpressionContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_repeatStatement

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRepeatStatement" ):
                return visitor.visitRepeatStatement(self)
            else:
                return visitor.visitChildren(self)




    def repeatStatement(self):

        localctx = PascalParser.RepeatStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 180, self.RULE_repeatStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 766
            self.match(PascalParser.REPEAT)
            self.state = 767
            self.statements()
            self.state = 768
            self.match(PascalParser.UNTIL)
            self.state = 769
            self.expression()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ForStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FOR(self):
            return self.getToken(PascalParser.FOR, 0)

        def identifier(self):
            return self.getTypedRuleContext(PascalParser.IdentifierContext,0)


        def ASSIGN(self):
            return self.getToken(PascalParser.ASSIGN, 0)

        def forList(self):
            return self.getTypedRuleContext(PascalParser.ForListContext,0)


        def DO(self):
            return self.getToken(PascalParser.DO, 0)

        def statement(self):
            return self.getTypedRuleContext(PascalParser.StatementContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_forStatement

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitForStatement" ):
                return visitor.visitForStatement(self)
            else:
                return visitor.visitChildren(self)




    def forStatement(self):

        localctx = PascalParser.ForStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 182, self.RULE_forStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 771
            self.match(PascalParser.FOR)
            self.state = 772
            self.identifier()
            self.state = 773
            self.match(PascalParser.ASSIGN)
            self.state = 774
            self.forList()
            self.state = 775
            self.match(PascalParser.DO)
            self.state = 776
            self.statement()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ForListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def initialValue(self):
            return self.getTypedRuleContext(PascalParser.InitialValueContext,0)


        def finalValue(self):
            return self.getTypedRuleContext(PascalParser.FinalValueContext,0)


        def TO(self):
            return self.getToken(PascalParser.TO, 0)

        def DOWNTO(self):
            return self.getToken(PascalParser.DOWNTO, 0)

        def getRuleIndex(self):
            return PascalParser.RULE_forList

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitForList" ):
                return visitor.visitForList(self)
            else:
                return visitor.visitChildren(self)




    def forList(self):

        localctx = PascalParser.ForListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 184, self.RULE_forList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 778
            self.initialValue()
            self.state = 779
            _la = self._input.LA(1)
            if not(_la==11 or _la==35):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 780
            self.finalValue()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InitialValueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self):
            return self.getTypedRuleContext(PascalParser.ExpressionContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_initialValue

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInitialValue" ):
                return visitor.visitInitialValue(self)
            else:
                return visitor.visitChildren(self)




    def initialValue(self):

        localctx = PascalParser.InitialValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 186, self.RULE_initialValue)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 782
            self.expression()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FinalValueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self):
            return self.getTypedRuleContext(PascalParser.ExpressionContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_finalValue

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFinalValue" ):
                return visitor.visitFinalValue(self)
            else:
                return visitor.visitChildren(self)




    def finalValue(self):

        localctx = PascalParser.FinalValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 188, self.RULE_finalValue)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 784
            self.expression()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class WithStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WITH(self):
            return self.getToken(PascalParser.WITH, 0)

        def recordVariableList(self):
            return self.getTypedRuleContext(PascalParser.RecordVariableListContext,0)


        def DO(self):
            return self.getToken(PascalParser.DO, 0)

        def statement(self):
            return self.getTypedRuleContext(PascalParser.StatementContext,0)


        def getRuleIndex(self):
            return PascalParser.RULE_withStatement

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitWithStatement" ):
                return visitor.visitWithStatement(self)
            else:
                return visitor.visitChildren(self)




    def withStatement(self):

        localctx = PascalParser.WithStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 190, self.RULE_withStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 786
            self.match(PascalParser.WITH)
            self.state = 787
            self.recordVariableList()
            self.state = 788
            self.match(PascalParser.DO)
            self.state = 789
            self.statement()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RecordVariableListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def variable(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PascalParser.VariableContext)
            else:
                return self.getTypedRuleContext(PascalParser.VariableContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(PascalParser.COMMA)
            else:
                return self.getToken(PascalParser.COMMA, i)

        def getRuleIndex(self):
            return PascalParser.RULE_recordVariableList

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRecordVariableList" ):
                return visitor.visitRecordVariableList(self)
            else:
                return visitor.visitChildren(self)




    def recordVariableList(self):

        localctx = PascalParser.RecordVariableListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 192, self.RULE_recordVariableList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 791
            self.variable()
            self.state = 796
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==46:
                self.state = 792
                self.match(PascalParser.COMMA)
                self.state = 793
                self.variable()
                self.state = 798
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





